@echo off
setlocal
cd /d "%~dp0"
if not defined OPENMSX_EXE set "OPENMSX_EXE=C:\Program Files\openMSX\openmsx.exe"
if not exist "%OPENMSX_EXE%" (
 echo Install openMSX or set OPENMSX_EXE to openmsx.exe.
 pause
 exit /b 1
)
set "OPENMSX_USER_DATA=%~dp0openmsx-user"
set "OPENMSX_HOME=%~dp0openmsx-home"
"%OPENMSX_EXE%" -setting "%~dp0settings.xml" -machine SATOREINKER_MSX1_32_NTSC -carta "%~dp0..\outputs\SAToReinker-Over-MSX1-PCG-v0.3.rom" -romtype ASCII8 -script "%~dp0launch.tcl"
endlocal
