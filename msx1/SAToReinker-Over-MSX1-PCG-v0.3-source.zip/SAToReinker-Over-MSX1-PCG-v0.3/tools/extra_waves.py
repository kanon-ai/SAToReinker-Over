"""Deterministic additional choreography for the isolated expanded MSX1 ROM.

The original six waves live unchanged in generate_assets.py. All additional
trajectories retain every in-bounds microdot; density is a design parameter,
never a runtime or PCG-dictionary overflow workaround.
"""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Wave:
    name: str
    description: str
    family: str
    variant: int = 0
    emitters: tuple = ()


CANDIDATES = [
    Wave("LOTUS BLOOM", "Six petals unfurl as alternating open rings.", "flower", 0, ((128, 88),)),
    Wave("SIDEWINDER", "Opposing side fans cross on diagonals.", "side", 0),
    Wave("DRIFTING GATES", "Broad moving openings guide a lateral dance.", "gate", 0),
    Wave("CRESCENT MOON", "Open crescents twist around a marked centre.", "crescent", 0, ((128, 88),)),
    Wave("PRISM RICOCHET", "A northern fan reflects into a zigzag prism.", "reflect", 0),
    Wave("RISING FOUNTAIN", "Wide upward fans rise from below the playfield.", "fountain", 0),
    Wave("DOUBLE HELIX", "Two bright helices weave through their shared axis.", "helix", 0),
    Wave("DIAMOND RAIN", "Slanted rain crosses an opposing geometric shower.", "diagonal", 0),
    Wave("CHERRY ORBIT", "Five petals sweep through a counter-rotating flower.", "flower", 1, ((128, 88),)),
    Wave("SWALLOWTAIL", "Side streams form a symmetric swallowtail.", "side", 1),
    Wave("SNAKE PASS", "A narrow gate winds left and right in long waves.", "gate", 1),
    Wave("BINARY CLOCK", "Paired four-hand clocks trace expanding arcs.", "clock", 0, ((72, 88), (184, 88))),
    Wave("WATERFALL PEARLS", "Pearled rainbows cascade in staggered vertical lanes.", "pearls", 0),
    Wave("KITE FESTIVAL", "Paired wing-like fans sweep across the centre.", "kite", 0),
    Wave("SUNFLOWER", "Golden-angle pinwheels bloom into a broad corona.", "flower", 2, ((128, 88),)),
    Wave("SCISSOR DANCE", "Opposing diagonal combs open and close like scissors.", "side", 2),
    Wave("IRIS GATES", "Alternating gate openings travel across the screen.", "gate", 2),
    Wave("LUNAR ECHO", "Two successive crescent clusters chase one another.", "crescent", 1, ((128, 88),)),
    Wave("MIRROR CASCADE", "Bent side-reflected streams descend as a lattice.", "reflect", 1),
    Wave("REVERSE RAIN", "Staggered rising waves demand a new direction of travel.", "fountain", 1),
    Wave("SILK RIBBONS", "Four thin paired ribbons make a flowing silk curtain.", "helix", 1),
    Wave("METEOR WEAVE", "Two coloured meteor showers cross with broad gaps.", "diagonal", 1),
    Wave("CLOVER CROWN", "Four-lobed rings evolve into a turning clover crown.", "flower", 3, ((128, 88),)),
    Wave("HOURGLASS", "Crossing side arcs make a rotating hourglass waist.", "side", 3),
    Wave("ALTERNATE DOORS", "Successive wide doors switch between left and right.", "gate", 3),
    Wave("ORBITAL CLOCK", "A six-hand spiral clock bends its rays in flight.", "clock", 1, ((128, 88),)),
    Wave("RAINBOW COMBS", "Interleaved combs descend with changing spacing.", "pearls", 1),
    Wave("BUTTERFLY WINGS", "Two edge fans draw opening butterfly wings.", "kite", 1),
    Wave("STAR ANEMONE", "Eight-point flowers stretch into star-shaped rings.", "flower", 4, ((128, 88),)),
    Wave("TIDAL CROSS", "Side-launched sine tides wash through one another.", "side", 4),
    Wave("WAVERING CORRIDOR", "Three broad slalom walls leave a winding corridor.", "gate", 4),
    Wave("ECLIPSE ARCS", "Sparse sweeping arcs leave an off-centre escape path.", "crescent", 2, ((128, 88),)),
    Wave("CRYSTAL RAIN", "Reflected narrow fans draw long crystal diagonals.", "reflect", 2),
    Wave("SKY BLOSSOM", "An upward fountain opens into two opposed bouquets.", "fountain", 2),
    Wave("QUANTUM BRAID", "Two asymmetric helices separate and rejoin.", "helix", 2),
    Wave("CHECKER COMETS", "Checker-spaced diagonals sweep in opposite directions.", "diagonal", 2),
    Wave("PETAL STORM", "A seven-petal flower pulses through alternating speeds.", "flower", 5, ((128, 88),)),
    Wave("HORIZON CROSS", "Two widely spaced side curtains exchange places.", "side", 5),
    Wave("SERPENT RIVER", "A rippling stream winds between banks of falling dots.", "gate", 5),
    Wave("CELESTIAL GEARS", "Two marked pinwheels turn like interlocking gears.", "clock", 2, ((76, 88), (180, 88))),
    Wave("SPARSE CONSTELLATION", "A gentle six-spoke constellation gives room to breathe.", "clock", 3, ((128, 88),)),
    Wave("SILVER STREAM", "A sparse winding shower closes the programme softly.", "pearls", 2),
]

# 31 added waves fit the 60 stream banks with all eleven families represented.
# Even the 32 cheapest candidates exceed that capacity before bank padding.
SELECTED_NAMES = (
    "LOTUS BLOOM", "DRIFTING GATES", "CRESCENT MOON", "PRISM RICOCHET",
    "RISING FOUNTAIN", "DOUBLE HELIX", "SNAKE PASS", "BINARY CLOCK",
    "KITE FESTIVAL", "SUNFLOWER", "IRIS GATES", "LUNAR ECHO", "MIRROR CASCADE",
    "REVERSE RAIN", "SILK RIBBONS", "METEOR WEAVE", "CLOVER CROWN",
    "ALTERNATE DOORS", "ORBITAL CLOCK", "STAR ANEMONE", "TIDAL CROSS",
    "WAVERING CORRIDOR", "ECLIPSE ARCS", "CRYSTAL RAIN", "SKY BLOSSOM",
    "QUANTUM BRAID", "CHECKER COMETS", "SERPENT RIVER", "CELESTIAL GEARS",
    "SPARSE CONSTELLATION", "SILVER STREAM",
)
SELECTED = [w for w in CANDIDATES if w.name in SELECTED_NAMES]


def reflected(x):
    x = (x - 6) % 488
    return 6 + (x if x <= 244 else 488 - x)


def generate(wave: Wave, frame: int):
    v = wave.variant
    family = wave.family
    if family == "flower":
        petals = (6, 5, 9, 4, 8, 7)[v]
        arms = (24, 25, 27, 24, 24, 28)[v]
        for ring, born in enumerate(range(16, 53, 6)):
            age = frame - born
            if age < 0:
                continue
            for arm in range(arms):
                phase = arm * math.tau / arms + ring * (0.071 + v * 0.012)
                twist = age * (0.006 if v & 1 else -0.006)
                radius = age * (3.7 + 0.3 * math.sin(petals * phase + ring * 0.45))
                if v == 2:
                    radius = age * (3.8 + (ring & 1) * 0.35)
                    twist += ring * 0.12
                if v == 4:
                    radius = age * (3.3 + 0.7 * abs(math.cos(4 * phase)))
                yield 128 + radius * math.cos(phase + twist), 88 + radius * math.sin(phase + twist), ring & 1
    elif family == "side":
        for ring, born in enumerate(range(8, 53, 5 if v < 3 else 6)):
            age = frame - born
            if age < 0:
                continue
            for side in range(2):
                direction = 1 if side == 0 else -1
                for arm in range(7 if v < 4 else 6):
                    x = (0 if side == 0 else 254) + direction * age * (4.0 + v * 0.06)
                    base_y = 46 + arm * 15 if v % 2 == 0 else 42 + arm * 16
                    slope = direction * (arm - 3) * (0.21 if v == 2 else 0.1)
                    y = base_y + slope * age
                    if v in (0, 4):
                        y += math.sin(age * 0.075 + ring * 0.4) * (12 if v == 0 else 23)
                    elif v in (1, 3):
                        y += direction * 20 * math.sin(age * 0.06 + arm * 0.42)
                    else:
                        y += 10 * math.sin(ring * 0.8)
                    yield x, y, side
    elif family == "gate":
        spacing = (10, 10, 12, 10, 12, 12)[v]
        for row, born in enumerate(range(8, 60, 8 if v < 3 else 9)):
            age = frame - born
            if age < 0:
                continue
            centre = 128 + (68 if v != 3 else 61) * math.sin(row * (0.74 if v != 3 else 1.5) + v * 0.4)
            width = (36, 32, 38, 44, 40, 36)[v]
            for x in range(8, 251, spacing):
                if abs(x - centre) < width / 2:
                    continue
                xx = x + (math.sin(age * 0.048 + row * 0.25) * 6 if v in (1, 4, 5) else 0)
                y = 18 + age * (3.15 + (v == 2) * 0.2)
                if v in (2, 5):
                    y += 5 * math.sin(x * 0.045 + row * 0.3)
                yield xx, y, row & 1
    elif family == "crescent":
        for ring, born in enumerate(range(16, 53, (7, 6, 9)[v])):
            age = frame - born
            if age < 0:
                continue
            arms = (22, 20, 18)[v]
            start = ring * (0.26 if v < 2 else 0.46) + v * 0.8
            for arm in range(arms):
                theta = start + arm * math.pi * (1.45 if v != 2 else 1.15) / (arms - 1)
                theta += age * (0.013 if ring & 1 else -0.009)
                radius = age * (3.7 + (ring & 1) * 0.25)
                yield 128 + math.cos(theta) * radius, 88 + math.sin(theta) * radius, ring & 1
    elif family == "reflect":
        for ring, born in enumerate(range(8, 55, (6, 5, 7)[v])):
            age = frame - born
            if age < 0:
                continue
            for arm in range((13, 11, 9)[v]):
                middle = ((13, 11, 9)[v] - 1) / 2
                vx = (arm - middle) * (0.95 if v != 2 else 1.15)
                vx += 0.75 * math.sin(ring * 0.65)
                x = reflected(128 + vx * age)
                yield x, 19 + age * (3.2 + v * 0.12), (arm + ring) & 1
    elif family == "fountain":
        for ring, born in enumerate(range(8, 53, (7, 6, 7)[v])):
            age = frame - born
            if age < 0:
                continue
            if v == 1:
                for stream in range(12):
                    yield 15 + stream * 20 + math.sin(age * 0.05 + stream * 0.4) * 10, 190 - age * 3.25, stream & 1
            else:
                for arm in range(17 if v == 0 else 15):
                    centre = 8 if v == 0 else 7
                    vx = (arm - centre) * 0.38 + math.sin(ring * 0.7) * 0.3
                    x = 128 + vx * age
                    if v == 2:
                        x += math.sin(age * 0.045) * (1 if arm > centre else -1) * 18
                    yield x, 190 - age * (3.15 + (ring & 1) * 0.1), ring & 1
    elif family == "helix":
        strands = 2 if v != 1 else 4
        for strand in range(strands):
            centre = (128 if v == 0 else (40 + strand * 58 if v == 1 else 90 + strand * 76))
            for born in range(8, 58, 3):
                age = frame - born
                if age < 0:
                    continue
                phase = age * (0.073 + v * 0.01) + strand * math.pi
                amplitude = (67, 24, 48)[v]
                x = centre + math.sin(phase) * amplitude
                for ribbon in range(2):
                    yield x + ribbon * 5 - 2, 19 + age * 3.05, strand & 1
    elif family == "diagonal":
        for wave_no, born in enumerate(range(8, 55, (5, 6, 6)[v])):
            age = frame - born
            if age < 0:
                continue
            for side in range(2):
                for lane in range(8 if v < 2 else 7):
                    x = -65 + lane * 42 + (1 if side == 0 else -1) * age * (2.05 + 0.2 * v)
                    if side:
                        x += 45
                    x += (wave_no & 1) * 9
                    yield x, 19 + age * (3.1 + side * 0.2), side
    elif family == "clock":
        centres = wave.emitters
        arms = (4, 6, 5, 6)[v]
        for ring, born in enumerate(range(16, 53, (4, 4, 5, 9)[v])):
            age = frame - born
            if age < 0:
                continue
            for source, (cx, cy) in enumerate(centres):
                for arm in range(arms):
                    direction = 1 if source == 0 else -1
                    theta = arm * math.tau / arms + direction * (ring * 0.24 + age * 0.015)
                    radius = age * (4.1 if len(centres) == 2 else 3.7)
                    yield cx + radius * math.cos(theta), cy + radius * math.sin(theta), (source + ring) & 1
    elif family == "pearls":
        for lane in range((10, 12, 7)[v]):
            for ring, born in enumerate(range(8 + (lane % 3), 57, (5, 6, 8)[v])):
                age = frame - born
                if age < 0:
                    continue
                x = 14 + lane * (24 if v == 0 else 20 if v == 1 else 36)
                x += math.sin(age * 0.065 + lane * 0.8) * (8 if v != 2 else 14)
                yield x, 19 + age * (3.1 + (lane & 1) * 0.15), (lane + ring) & 1
    elif family == "kite":
        for ring, born in enumerate(range(8, 55, 6)):
            age = frame - born
            if age < 0:
                continue
            for source, cx in enumerate((29, 227)):
                for arm in range(10 if v == 0 else 12):
                    theta = (arm - (4.5 if v == 0 else 5.5)) * 0.09
                    theta += (1 if source == 0 else -1) * (0.23 + math.sin(ring * 0.6) * 0.12)
                    x = cx + math.sin(theta) * age * 3.8
                    x += (1 if source == 0 else -1) * math.sin(age * 0.036) * (11 if v else 4)
                    yield x, 19 + math.cos(theta) * age * 3.8, source
    else:
        raise ValueError(f"Unknown choreography family: {family}")
