"""Package only this prototype and verify a clean source-archive rebuild."""
from pathlib import Path, PureWindowsPath
import hashlib,json,re,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
NAME='SAToReinker-Over-MSX1-PCG-v0.3'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def archive(path, files, overrides=None):
    overrides=overrides or {}
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for file in sorted(files):
            info=zipfile.ZipInfo(NAME+'/'+file.relative_to(ROOT).as_posix(),(2026,9,12,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,overrides[file] if file in overrides else file.read_bytes())

def public_report(path):
    """Publish portable evidence without rewriting the original local report."""
    def clean(value):
        if isinstance(value,dict):
            return {k:clean(v) for k,v in value.items() if k not in ('private_rom','private_profile')}
        if isinstance(value,list):return [clean(v) for v in value]
        if isinstance(value,str) and re.match(r'^(?:[A-Za-z]:[\\/]|\\\\)',value):
            try:return PureWindowsPath(value).relative_to(PureWindowsPath(str(ROOT))).as_posix()
            except ValueError:return '[external local path omitted]'
        if isinstance(value,str) and value.startswith('/'):
            try:return Path(value).relative_to(ROOT).as_posix()
            except ValueError:return '[external local path omitted]'
        return value
    doc=clean(json.loads(path.read_text(encoding='utf-8')))
    return (json.dumps(doc,indent=2,ensure_ascii=False)+'\n').encode('utf-8')

def main():
    rom=OUT/(NAME+'.rom')
    manifest=json.loads((OUT/'build-manifest.json').read_text())
    expected=sha(rom)
    assert len(rom.read_bytes())==524288 and manifest['sha256']==expected
    assert manifest['version']=='0.3' and manifest['stage_select']
    assert manifest['assets']['wave_loop_start']==0
    reports=['ntsc-verification.json','pal-verification.json','native-decode-verification.json',
             'sound-launcher-verification.json','route-verification.json','planned-play-verification.json',
             'stage-select-verification.json']
    waves=len(manifest['assets']['scenes'])
    assert waves==37
    for filename in reports:
        doc=json.loads((OUT/filename).read_text(encoding='utf-8'))
        assert doc.get('rom_sha256')==expected,(filename,'not final ROM')
        if filename=='stage-select-verification.json':
            assert doc.get('passed') is True,(filename,'stage selection checks failed')
    from PIL import Image
    extra_images=['title-stage-select.png','wave-37-stage-select.png',
                  'game-over-stage-select.png','pause-stage-select.png']
    for filename in extra_images:
        with Image.open(OUT/filename) as im:
            assert len(im.convert('RGB').getcolors(1000000))>4,filename+' is blank'
    files=[ROOT/'README.md',ROOT/'.gitignore']
    for directory in ('src','assets'):
        files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file())
    # Running the launcher creates caches and placeholder directories here.
    # Only the four portable launcher/configuration files are distributable.
    files.extend(ROOT/'play'/n for n in ('START.cmd','settings.xml','launch.tcl',
                 'openmsx-user/machines/SATOREINKER_MSX1_32_NTSC.xml'))
    tools=('build.py','generate_assets.py','extra_waves.py','emulator_support.py','verify_and_capture.py',
           'verify_pal.py','verify_native_decode.py','verify_sound_launcher.py','verify_routes.py',
           'verify_planned_play.py','verify_stage_select.py','package.py')
    files.extend(ROOT/'tools'/n for n in tools)
    assert all('systemroms' not in p.parts and p.suffix.lower() not in ('.dsk','.rom') for p in files)
    source=OUT/(NAME+'-source.zip')
    archive(source,files)
    (ROOT/'work').mkdir(exist_ok=True)
    clean=Path(tempfile.mkdtemp(prefix='source-rebuild-',dir=ROOT/'work')).resolve()
    assert clean.is_relative_to((ROOT/'work').resolve())
    with zipfile.ZipFile(source) as z:z.extractall(clean)
    project=clean/NAME
    subprocess.run([sys.executable,'tools/build.py'],cwd=project,check=True)
    rebuilt=project/'outputs'/rom.name
    assert sha(rebuilt)==expected,'Source archive did not reproduce the ROM'
    proof={'rom_sha256':expected,'source_archive_sha256':sha(source),'source_rebuild_sha256':sha(rebuilt),
           'byte_identical':True,'bios_or_disk_images_packaged':False}
    baseline=ROOT.parent/'graze-wave/outputs/SAToReinker-Over.rom'
    proof['original_v9990_preservation_check_performed']=baseline.is_file()
    if baseline.is_file():
        proof['original_v9990_rom_sha256']=sha(baseline)
        assert proof['original_v9990_rom_sha256']=='dcb1c0c6bd279ac3bc26f37056864ce5387db3217860bfad24573dc6ad1f88af'
    original_msx1=ROOT.parent/'graze-msx1/outputs/SAToReinker-Over-MSX1-PCG-v0.1.1.rom'
    proof['original_msx1_preservation_check_performed']=original_msx1.is_file()
    if original_msx1.is_file():
        proof['original_msx1_rom_sha256']=sha(original_msx1)
        assert proof['original_msx1_rom_sha256']=='624286f312a1286a54f8458cebfb54e5a6b9d041af4be29d3f3b07134f051cc7'
    expanded_msx1=ROOT.parent/'graze-msx1-expanded/outputs/SAToReinker-Over-MSX1-PCG-v0.2.rom'
    proof['v0_2_msx1_preservation_check_performed']=expanded_msx1.is_file()
    if expanded_msx1.is_file():
        proof['v0_2_msx1_rom_sha256']=sha(expanded_msx1)
        assert proof['v0_2_msx1_rom_sha256']=='9416c8348747fbbfa04dec7a2d1abdc26a87bff099c15e3c19b907b4fb50de63'
    (OUT/'rebuild-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
    public_names=reports+['build-manifest.json','rebuild-verification.json',rom.name]+extra_images
    public=[OUT/n for n in public_names]
    overrides={p:public_report(p) for p in public if p.suffix=='.json'}
    archive(OUT/(NAME+'-bundle.zip'),files+public,overrides)
    print(json.dumps(proof,indent=2))
    print(OUT/(NAME+'-bundle.zip'))

if __name__=='__main__':main()
