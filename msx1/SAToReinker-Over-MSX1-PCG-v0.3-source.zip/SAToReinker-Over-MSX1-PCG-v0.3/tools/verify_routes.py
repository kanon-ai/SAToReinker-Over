"""Offline exhaustive reachability with native movement and the visible 3x3 core.

This is a perfect-information route search, NOT a player difficulty rating or
an emulator capture. It decodes the final ROM packets independently and checks
one uninterrupted traversal of every wave, including its two repetitions.
"""
from pathlib import Path
import hashlib
import json
import struct

ROOT = Path(__file__).resolve().parents[1]
XMIN, XMAX, YMIN, YMAX = 8, 247, 32, 180
WIDTH, HEIGHT = XMAX-XMIN+1, YMAX-YMIN+1
FULL = (1 << WIDTH)-1
MOVES = [(0, 0, 0)]
for speed, slow in ((1, 32), (3, 0)):
    for dy in (-speed, 0, speed):
        for dx in (-speed, 0, speed):
            if dx or dy:
                MOVES.append((dx, dy, slow | (1 if dx<0 else 2 if dx>0 else 0) |
                              (4 if dy<0 else 8 if dy>0 else 0)))


def decode_dots(rom, symbols, scene, frame):
    """Independent packet decoder; occupancy comes from the ROM, not formulas."""
    runtime_base = 8192-0x8000
    index = runtime_base+symbols['frame_index']+(scene*128+frame)*3
    bank, address = struct.unpack_from('<BH', rom, index)
    assert 4 <= bank < 64 and 0x6000 <= address < 0x8000
    cursor = bank*8192 + address-0x6000
    masks = list(struct.unpack_from('<153H', rom, runtime_base+symbols['base_masks']))
    count = rom[cursor]; cursor += 1
    assert count <= 32
    for _ in range(count):
        masks.append(struct.unpack_from('<H', rom, cursor)[0]);cursor += 10
    names = []
    while rom[cursor]:
        token = rom[cursor];cursor += 1
        if token & 128:
            names.extend([0]*((token&127)+1))
        else:
            names.extend(rom[cursor:cursor+token]);cursor += token
    assert len(names)==768 and cursor < (bank+1)*8192
    dots=[]
    for cell, tile in enumerate(names):
        mask=masks[tile]
        for b in range(16):
            if mask & (1 << b):
                dots.append((cell%32*8+b%4*2,cell//32*8+b//4*2))
    return dots


def safe_rows(dots, half_core=1):
    blocked=[0]*HEIGHT
    for x,y in dots:
        # Bullet pixels x..x+1 intersect a centre +/-1 at x-1..x+2.
        lo=max(XMIN,x-half_core);hi=min(XMAX,x+1+half_core)
        if lo>hi:continue
        mask=((1 << (hi-lo+1))-1) << (lo-XMIN)
        for cy in range(max(YMIN,y-half_core),min(YMAX,y+1+half_core)+1):
            blocked[cy-YMIN] |= mask
    return tuple(FULL^row for row in blocked)


def advance(reachable, allowed):
    future=[0]*HEIGHT
    for speed in (1,3):
        low=(1<<speed)-1
        high=low << (WIDTH-speed)
        for y,row in enumerate(reachable):
            if not row:continue
            spread=row | (row >> speed) | ((row << speed)&FULL)
            if row&low:spread |= 1
            if row&high:spread |= 1 << (WIDTH-1)
            for target in (max(0,y-speed),y,min(HEIGHT-1,y+speed)):
                future[target] |= spread
    return tuple(row&mask for row,mask in zip(future,allowed))


def main():
    manifest=json.loads((ROOT/'outputs/build-manifest.json').read_text())
    symbols=json.loads((ROOT/'work/build/symbols.json').read_text())
    rom=(ROOT/'outputs'/manifest['file']).read_bytes()
    scene_count=len(manifest['assets']['scenes'])
    reachable=[0]*HEIGHT;reachable[166-YMIN]=1 << (128-XMIN)
    history=[tuple(reachable)]
    generous=tuple(reachable)
    generous_failure=None
    all_stationary=[FULL]*HEIGHT
    results=[]
    for scene in range(scene_count):
        dots=[decode_dots(rom,symbols,scene,f) for f in range(128)]
        allowed=[safe_rows(d) for d in dots]
        generous_allowed=[safe_rows(d,half_core=2) for d in dots]
        stationary=[FULL]*HEIGHT
        min_reachable=WIDTH*HEIGHT
        for f in range(256):
            safe=allowed[f%128]
            if f<128:stationary=[r&s for r,s in zip(stationary,safe)]
            reachable=advance(reachable,safe)
            count=sum(r.bit_count() for r in reachable)
            assert count, f'No route remains at wave {scene+1}, frame {f}'
            min_reachable=min(min_reachable,count)
            history.append(reachable)
            if generous_failure is None:
                generous=advance(generous,generous_allowed[f%128])
                if not any(generous):generous_failure={'wave':scene+1,'update_in_wave':f}
        all_stationary=[r&s for r,s in zip(all_stationary,stationary)]
        paths=[]
        for label,start_x,start_y,style in (
            ('still-centre',128,166,'still'),('still-left',8,166,'still'),
            ('still-right',247,166,'still'),('horizontal-sweep',128,166,'horizontal'),
            ('perimeter',8,32,'perimeter')):
            x,y=start_x,start_y;direction=1;leg=0;hit=None
            for f in range(256):
                if style=='horizontal':
                    if x>=247:direction=-1
                    if x<=8:direction=1
                    x=max(8,min(247,x+3*direction))
                elif style=='perimeter':
                    dx,dy=((3,0),(0,3),(-3,0),(0,-3))[leg]
                    x=max(8,min(247,x+dx));y=max(32,min(180,y+dy))
                    if (leg==0 and x==247) or (leg==1 and y==180) or (leg==2 and x==8) or (leg==3 and y==32):leg=(leg+1)%4
                if not (allowed[f%128][y-YMIN] >> (x-XMIN))&1:
                    hit=f;break
            paths.append({'name':label,'survived':hit is None,'hit_update':hit})
        entry={'wave':scene+1,'name':manifest['assets']['scenes'][scene]['name'],
               'minimum_reachable_centres':min_reachable,
               'stationary_safe_centres':sum(r.bit_count() for r in stationary),
               'simple_paths':paths}
        results.append(entry)
        print(json.dumps(entry),flush=True)
    # Recover a legal uninterrupted input stream for native follow-up testing.
    x,y=128,166
    if not (reachable[y-YMIN] >> (x-XMIN))&1:
        y=next(i for i,r in enumerate(reachable) if r)+YMIN
        row=reachable[y-YMIN];x=(row&-row).bit_length()-1+XMIN
    route=[];positions=[(x,y)]
    for past in reversed(history[:-1]):
        found=None
        for dx,dy,keys in MOVES:
            # Interior inverse is unique; clamps allow several source positions.
            xs=range(max(XMIN,x-3),min(XMAX,x+3)+1) if x in (XMIN,XMAX) else (x-dx,)
            ys=range(max(YMIN,y-3),min(YMAX,y+3)+1) if y in (YMIN,YMAX) else (y-dy,)
            for py in ys:
                if not YMIN<=py<=YMAX or max(YMIN,min(YMAX,py+dy))!=y:continue
                for px in xs:
                    if not XMIN<=px<=XMAX or max(XMIN,min(XMAX,px+dx))!=x:continue
                    if (past[py-YMIN] >> (px-XMIN))&1:
                        found=(px,py,keys);break
                if found:break
            if found:break
        assert found, 'Backtracking disagrees with forward native movement'
        x,y,keys=found;route.append(keys);positions.append((x,y))
    assert (x,y)==(128,166)
    route.reverse();positions.reverse()
    path=ROOT/'work/planned-inputs.bin';path.write_bytes(bytes(route))
    report={'rom_sha256':hashlib.sha256(rom).hexdigest(),'passed':True,
            'method':'Perfect-information integer reachability using final ROM occupancy, 3x3 core, native 1/3-pixel moves and clamps; no reaction-time model.',
            'native_runtime_test':False,'physical_hardware_tested':False,
            'waves':scene_count,'updates':len(route),'passes_per_wave':2,
            'larger_5x5_core_also_has_uninterrupted_route':generous_failure is None,
            'larger_core_first_failure':generous_failure,
            'whole_course_stationary_safe_centres':sum(r.bit_count() for r in all_stationary),
            'planned_input_sha256':hashlib.sha256(bytes(route)).hexdigest(),'results':results}
    (ROOT/'outputs/route-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Uninterrupted route exists:',len(route),'updates; stationary whole-course centres:',report['whole_course_stationary_safe_centres'])


if __name__=='__main__':main()
