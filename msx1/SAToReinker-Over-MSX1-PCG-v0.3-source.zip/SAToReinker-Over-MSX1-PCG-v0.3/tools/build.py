"""Build the isolated 32 KiB MSX1 PCG challenge; Python 3 + Pasmo."""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'work/build'
OUT = ROOT / 'outputs'

FONT = {
'0':['01110','10011','10101','10101','11001','10001','01110'],
'1':['00100','01100','00100','00100','00100','00100','01110'],
'2':['01110','10001','00001','00110','01000','10000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01110','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','01110'],
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'I':['01110','00100','00100','00100','00100','00100','01110'],
'J':['00111','00010','00010','00010','00010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','11001','10101','10011','10011','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'Q':['01110','10001','10001','10001','10101','10010','01101'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','10101','01010'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
'Z':['11111','00001','00010','00100','01000','10000','11111'],
':':['00000','00100','00100','00000','00100','00100','00000'],
'-':['00000','00000','00000','11111','00000','00000','00000'],
}

def main():
    BUILD.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    if '--reuse-assets' not in sys.argv:
        subprocess.run([sys.executable, str(ROOT/'tools/generate_assets.py')], check=True)
    patterns = bytearray((ROOT/'assets/base-patterns.bin').read_bytes())
    colors = bytearray((ROOT/'assets/base-colors.bin').read_bytes())
    for i, ch in enumerate(' 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ:-', 217):
        rows = FONT.get(ch, ['00000']*7)
        patterns[i*8:i*8+8] = bytes([int(s,2)<<2 for s in rows]+[0])
        colors[i*8:i*8+8] = bytes([0xF1,0xF1,0x71,0x71,0x71,0x51,0x51,0x11])
    # Immutable font and fixed PCG pages are prepared entirely off screen.
    (BUILD/'patterns.bin').write_bytes(patterns)
    (BUILD/'colors.bin').write_bytes(colors)
    pasmo = os.environ.get('PASMO', 'C:/Software/Pasmo/pasmo.exe')
    subprocess.run([pasmo,'--bin','src/main.asm','work/build/runtime.bin','work/build/symbols.txt'], cwd=ROOT,check=True)
    runtime = (BUILD/'runtime.bin').read_bytes()
    assert len(runtime)<=24576, f'Runtime exceeds 24KiB: {len(runtime)}'
    subprocess.run([pasmo,'--bin','src/boot.asm','work/build/boot.bin'],cwd=ROOT,check=True)
    boot=(BUILD/'boot.bin').read_bytes()
    assert len(boot)==8192
    stream=(ROOT/'assets/stream.bin').read_bytes()
    assert len(stream)<=60*8192
    rom=bytearray([255])*524288
    rom[:8192]=boot
    rom[8192:8192+len(runtime)]=runtime
    rom[32768:32768+len(stream)]=stream
    target=OUT/'SAToReinker-Over-MSX1-PCG-v0.3.rom'
    target.write_bytes(rom)
    symbols={name:int(value,16) for name,value in re.findall(r'^(\w+)\s+EQU\s+0*([0-9A-F]+)H', (BUILD/'symbols.txt').read_text(), re.M|re.I)}
    (BUILD/'symbols.json').write_text(json.dumps(symbols,indent=2)+'\n')
    scenes=json.loads((ROOT/'assets/scenes.json').read_text())
    manifest=dict(title='SAToReinker-Over MSX1 PCG Challenge - Stage Select',version='0.3',file=target.name,
        mapper='ASCII8',rom_bytes=len(rom),ram_required_bytes=32768,vram_bytes=16384,
        runtime_bytes=len(runtime),runtime_address='8000-DFFF',working_ram='E000-E91F',stack_top='F300',
        replay=False,stage_select=True,video='TMS9918A SCREEN2 256x192; 2x2-pixel PCG bullets; two name tables and separate dynamic PCG sets',
        physical_hardware_tested=False,sha256=hashlib.sha256(rom).hexdigest(),assets=scenes)
    (OUT/'build-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k!='assets'},indent=2))

if __name__=='__main__':main()
