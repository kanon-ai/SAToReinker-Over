"""Play the final ROM through keyboard input from a fully precomputed route.

No game RAM, CPU registers, ROM bytes or invincibility flags are written.
Breakpoints observe native updates and set only the emulated keyboard matrix.
This proves one perfect-information machine-input route, not player difficulty,
real-time reaction feasibility or physical-hardware compatibility.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

from emulator_support import OpenMSX, read_symbols, tcl_word

ROOT = Path(__file__).resolve().parents[1]

TCL_RUNNER = r'''
namespace eval ::planned {
    array set address {@ADDRESSES@}
    variable total @TOTAL@
    variable inputs
    set channel [open @INPUT_PATH@ rb]
    binary scan [read $channel] cu* inputs
    close $channel
    variable trace [open @TRACE_PATH@ w]
    fconfigure $trace -translation lf
    puts $trace "index\tscene\tpass\tframe\tmode\tx\ty\tkeys\tupdate_count"
    variable started 0
    variable prepared 0
    variable committed 0
    variable done 0
    variable failure ""
    variable first_count 0
    variable first_time 0
    variable last_time 0
    variable expected_x 128
    variable expected_y 166
}
proc ::planned::byte {name} {
    return [debug read memory $::planned::address($name)]
}
proc ::planned::counter {} {
    set a $::planned::address(update_count)
    return [expr {[debug read memory $a] | ([debug read memory [expr {$a+1}]] << 8)}]
}
proc ::planned::stop {message} {
    set ::planned::failure $message
    set ::planned::last_time [machine_info time]
    set ::planned::done 1
    catch {close $::planned::trace}
    keymatrixup 8 241
    keymatrixup 6 1
    debug break
    set pause on
}
proc ::planned::main_hook {} {
    if {$::planned::done} {return}
    if {[catch {::planned::prepare_input} message]} {
        ::planned::stop $message
    }
}
proc ::planned::prepare_input {} {
    if {!$::planned::started} {
        if {[::planned::byte mode] != 0} {error "Expected the native title before SPACE"}
        set ::planned::first_count [::planned::counter]
        set ::planned::first_time [machine_info time]
        set ::planned::started 1
    } else {
        if {$::planned::prepared != $::planned::committed} {error "Missing committed frame"}
        if {[::planned::counter] != (($::planned::first_count+$::planned::committed)&65535)} {
            error "Native update counter does not match completed inputs"
        }
        if {$::planned::committed == $::planned::total} {
            if {[::planned::byte mode] != 1} {error "Run did not remain in ordinary play"}
            ::planned::stop ""
            return
        }
    }
    set index $::planned::committed
    set keys [lindex $::planned::inputs $index]
    set row8 [expr {(($keys&1)?16:0) | (($keys&2)?128:0) |
                    (($keys&4)?32:0) | (($keys&8)?64:0)}]
    # SPACE and route[0] must be sampled together: reset_run is followed by
    # move_player and frame-0 collision processing in this same native update.
    if {$index == 0} {set row8 [expr {$row8|1}]}
    keymatrixup 8 241
    keymatrixup 6 1
    if {$row8} {keymatrixdown 8 $row8}
    if {$keys&32} {keymatrixdown 6 1}
    incr ::planned::prepared
}
proc ::planned::commit_hook {} {
    if {!$::planned::started || $::planned::done} {return}
    if {[catch {::planned::observe_frame} message]} {
        ::planned::stop $message
    }
}
proc ::planned::observe_frame {} {
    set index $::planned::committed
    if {$::planned::prepared != $index+1} {error "Unexpected committed frame"}
    set scene [::planned::byte scene]
    set pass [::planned::byte scene_pass]
    set frame [::planned::byte frame]
    set mode [::planned::byte mode]
    set x [::planned::byte player_x]
    set y [::planned::byte player_y]
    set keys [::planned::byte keys]
    set count [::planned::counter]
    puts $::planned::trace [join [list $index $scene $pass $frame $mode $x $y $keys $count] "\t"]
    if {$mode != 1} {error "Native hit or mode change at input $index: mode=$mode wave=[expr {$scene+1}] frame=$frame"}
    if {$scene != $index/256 || $pass != ($index/128)%2 || $frame != $index%128} {
        error "Route phase mismatch at input $index: scene=$scene pass=$pass frame=$frame"
    }
    set planned_keys [lindex $::planned::inputs $index]
    set expected_keys [expr {$planned_keys | (($index==0)?16:0)}]
    if {$keys != $expected_keys} {error "Native keys mismatch at input $index: $keys != $expected_keys"}
    if {$count != (($::planned::first_count+$index)&65535)} {error "Native commit counter mismatch"}
    set speed [expr {($planned_keys&32)?1:3}]
    set dx [expr {(($planned_keys&2)!=0)-(($planned_keys&1)!=0)}]
    set dy [expr {(($planned_keys&8)!=0)-(($planned_keys&4)!=0)}]
    set ::planned::expected_x [expr {$::planned::expected_x+$dx*$speed}]
    set ::planned::expected_y [expr {$::planned::expected_y+$dy*$speed}]
    if {$::planned::expected_x < 8} {set ::planned::expected_x 8}
    if {$::planned::expected_x > 247} {set ::planned::expected_x 247}
    if {$::planned::expected_y < 32} {set ::planned::expected_y 32}
    if {$::planned::expected_y > 180} {set ::planned::expected_y 180}
    if {$x != $::planned::expected_x || $y != $::planned::expected_y} {
        error "Native movement mismatch at input $index: $x,$y != $::planned::expected_x,$::planned::expected_y"
    }
    incr ::planned::committed
}
set ::planned::main_bp [debug set_bp @MAIN_LOOP@ {} {::planned::main_hook}]
set ::planned::commit_bp [debug set_bp @FRAME_COMMITTED@ {} {::planned::commit_hook}]
'''


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str):
    if not condition:
        raise AssertionError(message)


def run(args):
    manifest = json.loads((ROOT / "outputs/build-manifest.json").read_text())
    route_report = json.loads((ROOT / "outputs/route-verification.json").read_text())
    symbols = {k.lower(): v for k, v in read_symbols(ROOT / "work/build/symbols.json").items()}
    source_rom = ROOT / "outputs" / manifest["file"]
    rom = source_rom.read_bytes()
    inputs = (ROOT / "work/planned-inputs.bin").read_bytes()
    waves = len(manifest["assets"]["scenes"])
    rom_hash, input_hash = digest(rom), digest(inputs)
    require(rom_hash == manifest["sha256"] == route_report["rom_sha256"], "ROM/route report mismatch")
    require(input_hash == route_report["planned_input_sha256"], "Planned input hash mismatch")
    require(route_report["passed"] and route_report["passes_per_wave"] == 2, "Route planner did not pass")
    require(len(inputs) == waves * 256 == route_report["updates"], "Expected two full passes of every wave")
    require(all(not (k & ~0x2F) and k & 3 != 3 and k & 12 != 12 for k in inputs),
            "Route contains forbidden keys or opposing directions")
    require(len(rom) == 524288 and manifest["assets"]["frames_per_scene"] == 128,
            "Unexpected ROM size or frame layout")
    report = {
        "passed": False, "rom_sha256": rom_hash, "planned_input_sha256": input_hash,
        "standard": args.standard, "waves": waves, "passes_per_wave": 2,
        "planned_updates": len(inputs), "physical_hardware_tested": False,
        "human_play_tested": False, "reaction_time_modelled": False,
        "game_ram_writes": False, "cpu_register_writes": False, "invincibility_used": False,
        "method": "Perfect-information precomputed route delivered through emulated keyboard input to the actual ROM; native breakpoints only observe game state and schedule keyboard input.",
        "scope": "One continuous machine-input survival route. This is not evidence of player difficulty, practical reaction time or real-hardware operation.",
    }
    output = args.output or ROOT / "outputs/planned-play-verification.json"
    try:
        with OpenMSX(args.standard) as emu:
            private_rom = emu.profile.directory / manifest["file"]
            private_inputs = emu.profile.directory / "planned-inputs.bin"
            trace = emu.profile.directory / "planned-play-trace.tsv"
            private_rom.write_bytes(rom)
            private_inputs.write_bytes(inputs)
            emu.load_rom(private_rom, "ASCII8")
            emu.run_for(5)
            report["machine"] = emu.machine_info()
            require(report["machine"]["ram_bytes"] == 32768, "Test must use real 32 KiB RAM configuration")
            require(report["machine"]["vram_bytes"] == 16384, "Test must use 16 KiB VRAM")
            require(emu.read_symbol(symbols, "mode") == 0, "Native title did not boot")
            device = emu.command(f"lsearch -inline [debug list] {tcl_word('*' + manifest['file'])}")
            require(bool(device), "Native ROM debug device missing")
            require(digest(emu.read_block(device, 0, len(rom))) == rom_hash, "Executed ROM differs from final build")
            runtime_before = emu.read_block("memory", 0x8000, manifest["runtime_bytes"])
            replacements = {
                "@ADDRESSES@": " ".join(f"{n} {symbols[n]}" for n in
                    ("mode", "scene", "scene_pass", "frame", "player_x", "player_y", "keys", "update_count")),
                "@TOTAL@": str(len(inputs)), "@INPUT_PATH@": tcl_word(private_inputs.as_posix()),
                "@TRACE_PATH@": tcl_word(trace.as_posix()), "@MAIN_LOOP@": str(symbols["main_loop"]),
                "@FRAME_COMMITTED@": str(symbols["frame_committed"]),
            }
            script = TCL_RUNNER
            for token, value in replacements.items():
                script = script.replace(token, value)
            script_path = emu.profile.directory / "planned-play.tcl"
            script_path.write_text(script, encoding="utf-8")
            emu.command(f"source {tcl_word(script_path.as_posix())}")
            start_wall = time.monotonic()
            next_notice = start_wall
            emu.command("set pause off;debug cont")
            while True:
                done, committed = map(int, emu.command("list $::planned::done $::planned::committed").split())
                now = time.monotonic()
                if done:
                    break
                if now >= next_notice:
                    print(f"Native planned play: {committed}/{len(inputs)} committed inputs", flush=True)
                    next_notice = now + 5
                if now - start_wall > args.timeout:
                    emu.command('::planned::stop "Host-time timeout"')
                    raise TimeoutError("Native route exceeded host-time timeout")
                time.sleep(0.05)
            emu.command("set pause on")
            failure = emu.command("set ::planned::failure")
            report["committed_updates"] = committed
            report["host_seconds"] = time.monotonic() - start_wall
            report["emulated_seconds"] = float(emu.command("expr {$::planned::last_time-$::planned::first_time}"))
            report["trace"] = trace.relative_to(ROOT).as_posix()
            report["final_mode"] = emu.read_symbol(symbols, "mode")
            report["final_scene"] = emu.read_symbol(symbols, "scene")
            report["final_frame"] = emu.read_symbol(symbols, "frame")
            report["final_scene_pass"] = emu.read_symbol(symbols, "scene_pass")
            score_digits = emu.read_block("memory", symbols["score"], 6)
            report["final_score"] = sum(d * (10 ** i) for i, d in enumerate(score_digits))
            report["vram_timing_violations"] = emu.timing_violations()
            report["native_rom_unchanged"] = digest(emu.read_block(device, 0, len(rom))) == rom_hash
            report["native_runtime_unchanged"] = runtime_before == emu.read_block("memory", 0x8000, len(runtime_before))
            lines = trace.read_text().splitlines()
            samples = [list(map(int, line.split("\t"))) for line in lines[1:]]
            report["observed_frames"] = len(samples)
            report["per_wave_commits"] = [sum(row[1] == scene for row in samples) for scene in range(waves)]
            require(not failure, failure)
            require(committed == len(inputs) == len(samples), "Route was not fully committed")
            require(all(count == 256 for count in report["per_wave_commits"]), "Missing wave/pass samples")
            require(report["final_mode"] == 1, "Native run ended outside ordinary play")
            require(report["final_scene"] == symbols["wave_loop_start"] and
                    report["final_frame"] == 0 and report["final_scene_pass"] == 0,
                    "Run did not wrap from the final wave to the WAVE 1")
            require(report["vram_timing_violations"] == 0, "Strict VRAM timing violation")
            require(report["native_rom_unchanged"] and report["native_runtime_unchanged"], "ROM/runtime changed")
        report["source_rom_unchanged"] = digest(source_rom.read_bytes()) == rom_hash
        require(report["source_rom_unchanged"], "Source ROM changed during verification")
        report["passed"] = True
        print(f"PASS: {waves} waves, {len(inputs)} inputs, ordinary play, no hit", flush=True)
    except BaseException as exc:
        report["error"] = str(exc)
        raise
    finally:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--standard", choices=("ntsc", "pal"), default="ntsc")
    parser.add_argument("--timeout", type=float, default=180,
                        help="Maximum host seconds after starting native keyboard playback")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--syntax-only", action="store_true")
    args = parser.parse_args()
    if not args.syntax_only:
        run(args)


if __name__ == "__main__":
    main()
