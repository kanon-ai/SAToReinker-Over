"""Native stage-select checks on isolated 32 KiB NTSC/PAL MSX1 machines.

Menus and both 37-to-1 traversals use only emulated keyboard input. The normal
route is independently planned from final-ROM occupancy, with live collisions
and scoring; it is an existence check, not a player difficulty measurement.
The joystick decoder is unchanged and inspected separately; this tool does
not test physical joystick input or real MSX hardware.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time

from emulator_support import OpenMSX, tcl_word
from verify_planned_play import TCL_RUNNER
from verify_routes import (XMIN, XMAX, YMIN, YMAX, HEIGHT, MOVES,
                           decode_dots, safe_rows, advance)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def plan_selected_route(rom, symbols, start=36, updates=512, waves=37):
    reachable = [0] * HEIGHT
    reachable[166-YMIN] = 1 << (128-XMIN)
    history = [tuple(reachable)]
    for index in range(updates):
        scene, frame = (start + index//256) % waves, index % 128
        reachable = advance(reachable, safe_rows(decode_dots(rom, symbols, scene, frame)))
        assert any(reachable), ('No selected-start route', index)
        history.append(reachable)
    y = next(i for i, row in enumerate(reachable) if row) + YMIN
    row = reachable[y-YMIN]
    x = (row & -row).bit_length()-1 + XMIN
    route = []
    for past in reversed(history[:-1]):
        found = None
        for dx, dy, keys in MOVES:
            xs = range(max(XMIN, x-3), min(XMAX, x+3)+1) if x in (XMIN, XMAX) else (x-dx,)
            ys = range(max(YMIN, y-3), min(YMAX, y+3)+1) if y in (YMIN, YMAX) else (y-dy,)
            for py in ys:
                if not YMIN <= py <= YMAX or max(YMIN, min(YMAX, py+dy)) != y:
                    continue
                for px in xs:
                    if (XMIN <= px <= XMAX and max(XMIN, min(XMAX, px+dx)) == x
                            and (past[py-YMIN] >> (px-XMIN)) & 1):
                        found = px, py, keys
                        break
                if found:
                    break
            if found:
                break
        assert found
        x, y, keys = found
        route.append(keys)
    assert (x, y) == (128, 166)
    return bytes(reversed(route))


def run_selected_course(e, symbols, route, work, demo=False):
    """Observe every native commit, with only keyboard changes in breakpoints."""
    route_path = work / ('demo-inputs.bin' if demo else 'normal-inputs.bin')
    route_path.write_bytes(route)
    trace = work / ('demo-native.tsv' if demo else 'normal-native.tsv')
    script = TCL_RUNNER.replace('$scene != $index/256', '$scene != (36+$index/256)%37')
    script = script.replace('keymatrixup 6 1', 'keymatrixup 6 1\n    keymatrixup 3 2')
    script = script.replace('update_count"', 'update_count\\tscore"')
    script = script.replace('$x $y $keys $count]', '$x $y $keys $count [::planned::score]]')
    script += '\nproc ::planned::score {} {set n 0;set m 1;for {set i 0} {$i<6} {incr i} {incr n [expr {$m*[debug read memory [expr {$::planned::address(score)+$i}]]}];set m [expr {$m*10}]};return $n}\n'
    if demo:
        script = script.replace('!= 1', '!= 4')
        script = script.replace('if {$index == 0} {set row8 [expr {$row8|1}]}', '')
        script = script.replace('if {$keys&32} {keymatrixdown 6 1}', 'if {$keys&32} {keymatrixdown 6 1}\n    if {$index == 0} {keymatrixdown 3 2}')
        script = script.replace('(($index==0)?16:0)', '(($index==0)?128:0)')
    replacements = {
        '@ADDRESSES@': ' '.join(f'{name} {symbols[name]}' for name in
            ('mode','scene','scene_pass','frame','player_x','player_y','keys','update_count','score')),
        '@TOTAL@': str(len(route)), '@INPUT_PATH@': tcl_word(route_path.as_posix()),
        '@TRACE_PATH@': tcl_word(trace.as_posix()), '@MAIN_LOOP@': str(symbols['main_loop']),
        '@FRAME_COMMITTED@': str(symbols['frame_committed']),
    }
    for token, value in replacements.items():
        script = script.replace(token, value)
    path = work / ('demo-course.tcl' if demo else 'normal-course.tcl')
    path.write_text(script, encoding='utf-8')
    e.command(f'source {tcl_word(path.as_posix())};set pause off;debug cont')
    deadline = time.monotonic()+90
    while e.command('set ::planned::done') != '1':
        if time.monotonic() > deadline:
            raise TimeoutError('Selected-wave native route timeout')
        time.sleep(.025)
    failure = e.command('set ::planned::failure')
    assert not failure, failure
    e.command('debug remove_bp $::planned::main_bp;debug remove_bp $::planned::commit_bp')
    samples = [list(map(int, line.split('\t'))) for line in trace.read_text().splitlines()[1:]]
    assert len(samples) == len(route)
    scores = [row[-1] for row in samples]
    assert all(b > a for a, b in zip(scores, scores[1:]))
    get = lambda n: e.read_symbol(symbols, n)
    assert (get('scene'), get('frame'), get('scene_pass'), get('selected_wave')) == (1, 0, 0, 36)
    assert get('loop_count') == 1 and get('mode') == (4 if demo else 1)
    result = dict(passed=True, updates=len(samples), wave37_updates=256, wave1_updates=256,
                  input_sha256=sha(route), final_wave=2, final_mode=get('mode'),
                  selected_wave=37, loop_count=1, final_score=scores[-1],
                  transition_scores=[scores[255], scores[256]],
                  strictly_increasing_score=True, gameplay_ram_writes=False,
                  cpu_register_writes=False, live_collisions=not demo,
                  invincible_showcase=demo, trace=trace.relative_to(ROOT).as_posix())
    e.command('namespace delete ::planned;debug cont')
    return result



def capture_selection_screens(rom_path, symbols):
    """One untouched native bitmap from each fresh realtime renderer session.

    Keep capture provenance and review the actual stored PNG pixels. Chat
    previews were observed to differ for byte-identical files, so preview
    differences alone are not evidence of a rendering fault. Never composite.
    """
    proof = dict(rom_sha256=sha(rom_path.read_bytes()), physical_hardware_tested=False,
                 method='Fresh realtime openMSX session per screenshot; first screenshot only, rendered framebuffer, no OSD or pixel editing.',
                 limitation='Chat previews were observed to differ for byte-identical PNGs; final review compares the stored image pixels.',
                 images=[])
    specifications = [('title-stage-select.png',36,'title'),
                      ('game-over-stage-select.png',36,'gameover'),
                      ('pause-stage-select.png',36,'pause'),
                      ('wave-37-stage-select.png',36,'demo')]
    for filename, selected, state in specifications:
        with OpenMSX('ntsc',capture=True) as e:
            e.command('set throttle on;set vsync true')
            e.load_rom(rom_path,'ASCII8');e.run_for(5)
            get=lambda name:e.read_symbol(symbols,name)
            def tap(row,mask):
                e.key(row,mask);e.run_for(.12);e.key(row,mask,False);e.run_for(.18)
            if selected:tap(8,16)
            if state in ('demo','pause'):
                tap(3,2)
                if state=='pause':tap(7,4)
                else:e.run_for(1.4)
            if state=='gameover':
                tap(8,1)
                for _ in range(120):
                    if get('mode')==2:break
                    e.run_for(.25)
                assert get('mode')==2
                # Show matching selection and background in the review still.
                tap(8,128);tap(8,16)
            e.run_for(.3)
            expected_mode={'title':0,'gameover':2,'pause':3,'demo':4}[state]
            assert get('mode')==expected_mode and get('selected_wave')==selected
            regs=e.read_block('VDP regs',0,8)
            base=(regs[2]&15)*1024
            names=e.read_block('physical VRAM',base,768)
            assert names[33:38]==bytes([246,230,242,245,232])
            assert names[6*32+8:6*32+18]==bytes([246,228,247,242,245,232,236,241,238,232]) if state!='demo' else True
            file=OUT/filename
            e.command('screenshot '+tcl_word(file.as_posix()))
            proof['images'].append(dict(file=filename,sha256=sha(file.read_bytes()),
                mode=get('mode'),selected_wave=selected+1,displayed_wave=get('scene')+1,
                native_names_sha256=sha(names),VRAM_timing_violations=e.timing_violations(),
                game_RAM_writes=False,CPU_register_writes=False))
            print('Fresh screenshot',filename,flush=True)
    (OUT/'stage-select-capture-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--standard', choices=('ntsc','pal','both'), default='both')
    parser.add_argument('--syntax-only', action='store_true')
    parser.add_argument('--captures-only', action='store_true')
    args = parser.parse_args()
    if args.syntax_only:
        return
    manifest = json.loads((OUT/'build-manifest.json').read_text())
    symbols = {k.lower(): v for k,v in json.loads((ROOT/'work/build/symbols.json').read_text()).items()}
    rom_path = OUT/manifest['file']
    rom = rom_path.read_bytes()
    assert sha(rom) == manifest['sha256'] and len(rom) == 524288
    assert symbols['wave_count'] == 37 and symbols['wave_loop_start'] == 0
    if args.captures_only:
        capture_selection_screens(rom_path,symbols)
        return
    work = ROOT/'work/stage-select-verification'
    work.mkdir(parents=True, exist_ok=True)
    route = plan_selected_route(rom, symbols)
    report = dict(rom_sha256=sha(rom), physical_hardware_tested=False,
                  scope='Native keyboard menus and selected-start routes; physical joystick input is not tested.',
                  capture_method='Separate fresh realtime emulator sessions, one rendered screenshot each; review stored PNG pixels independently of chat previews.',
                  standards={}, passed=False)
    output = OUT/'stage-select-verification.json'
    try:
        for standard in ('ntsc','pal') if args.standard == 'both' else (args.standard,):
            checks = []
            sub = report['standards'][standard] = {'checks':checks}
            standard_work = work/standard
            standard_work.mkdir(parents=True, exist_ok=True)
            def check(name, condition, **evidence):
                checks.append(dict(name=name, passed=bool(condition), **evidence))
                print(standard, name, bool(condition), evidence, flush=True)
                assert condition, name
            with OpenMSX(standard) as e:
                e.command('set throttle off;set vsync false')
                e.load_rom(rom_path, 'ASCII8')
                e.run_for(5)
                get = lambda n, size=1: e.read_symbol(symbols,n,size)
                def tap(row, mask, hold=.12):
                    e.key(row, mask);e.run_for(hold);e.key(row, mask, False);e.run_for(.08)
                sub['machine'] = e.machine_info()
                check('RAM32-VRAM16', sub['machine']['ram_bytes']==32768 and sub['machine']['vram_bytes']==16384)
                device = e.command(f'lsearch -inline [debug list] {tcl_word("*"+rom_path.name)}')
                check('actual-ROM', sha(e.read_block(device,0,len(rom))) == sha(rom))
                runtime = e.read_block('memory',0x8000,manifest['runtime_bytes'])
                check('boot-wave1-title', (get('mode'),get('selected_wave'),get('scene')) == (0,0,0))
                tap(8,16)
                check('left-wrap-to37', get('selected_wave')==36 and get('scene')==36)
                tap(8,128)
                check('right-wrap-to1', get('selected_wave')==0)
                e.key(8,128);e.run_for(1.1)
                check('held-right-one-change', get('selected_wave')==1)
                e.key(8,128,False);e.run_for(.1)
                tap(8,128)
                check('release-repress-changes-again',get('selected_wave')==2)
                tap(8,144)
                check('opposed-directions-cancel',get('selected_wave')==2)
                observed=[]
                for _ in range(37):
                    tap(8,128,.08);observed.append(get('selected_wave'))
                check('all37-selectable-and-wrap',observed==[(3+i)%37 for i in range(37)])
                for _ in range(3):tap(8,16)
                check('selected37-before-title-animation',get('selected_wave')==36)
                e.run_for(9.2)
                check('title-preview-keeps-selected-wave', (get('mode'),get('scene'),get('selected_wave'),get('scene_pass'))==(0,36,36,0))
                regs=e.read_block('VDP regs',0,8)
                base=(regs[2]&15)*1024
                digits=list(e.read_block('physical VRAM',base+13*32+11,2))
                check('displayed-selection37',digits==[221,225],tiles=digits)
                e.key(8,129);e.run_for(.10);e.key(8,129,False);e.run_for(.05)
                check('SPACE-priority-over-right-starts37',get('mode')==1 and get('scene')==36 and get('selected_wave')==36)
                for _ in range(100):
                    if get('mode')==2:break
                    e.run_for(.25)
                check('natural-hit-game-over',get('mode')==2,scene=get('scene'),frame=get('frame'))
                tap(8,128)
                check('gameover-right-wraps',get('mode')==2 and get('selected_wave')==0)
                tap(8,16)
                check('gameover-left-wraps',get('selected_wave')==36)
                e.key(8,16);e.run_for(.8);e.key(8,16,False);e.run_for(.1)
                check('gameover-held-left-one-change',get('selected_wave')==35)
                tap(8,128)
                tap(3,2)
                check('gameover-D-starts-selected-DEMO',get('mode')==4 and get('scene')==36)
                tap(7,4)
                paused=(get('frame'),get('score_tick'))
                check('DEMO-pause',get('mode')==3 and get('previous_mode')==4)
                e.run_for(.4)
                check('pause-freezes-frame',get('frame')==paused[0])
                e.key(8,1);e.run_for(.7)
                check('paused-DEMO-exit-keeps-choice-and-held-fire',get('mode')==0 and get('scene')==36 and get('selected_wave')==36)
                e.key(8,1,False);e.run_for(.1)
                tap(8,1)
                check('retry-starts-selected-wave',get('mode')==1 and get('scene')==36 and get('selected_wave')==36)
                tap(7,4)
                frame=get('frame')
                check('normal-pause',get('mode')==3 and get('previous_mode')==1)
                e.run_for(.4)
                check('normal-pause-freezes-frame',get('frame')==frame)
                tap(7,4)
                check('normal-resume',get('mode')==1)
                check('menu-test-runtime-unchanged',runtime==e.read_block('memory',0x8000,len(runtime)))
                check('menu-test-VRAM-timing',e.timing_violations()==0,count=e.timing_violations())
            for demo in (False,True):
                with OpenMSX(standard) as e:
                    e.load_rom(rom_path,'ASCII8');e.run_for(5)
                    e.key(8,16);e.run_for(.1);e.key(8,16,False);e.run_for(.1)
                    assert e.read_symbol(symbols,'selected_wave')==36
                    current = bytes(512) if demo else route
                    evidence=run_selected_course(e,symbols,current,standard_work, demo)
                    evidence['VRAM_timing_violations']=e.timing_violations()
                    check(('DEMO' if demo else 'normal')+'-37-to1-continuous',e.timing_violations()==0,score=evidence['final_score'])
                    sub['demo_course' if demo else 'normal_course']=evidence
            sub['passed']=True
        if args.standard in ('ntsc','both'):
            capture_selection_screens(rom_path,symbols)
        report['passed']=True
    except BaseException as exc:
        report['error']=str(exc)
        raise
    finally:
        output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
