"""Read-only ROM check: native PSG activity, pause/resume and portable launcher.

Runs one hidden private NTSC 32 KiB openMSX instance. Ordinary audio and pause
checks use keyboard input. Explicit scene/frame fixtures then verify late-wave
tempo bounds; those fixtures are not ordinary gameplay or survival evidence.
The WAV check establishes nonzero native PCM, not a subjective listening review.
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import uuid
import wave
import xml.etree.ElementTree as ET

from emulator_support import OpenMSX, read_symbols, tcl_word

ROOT = Path(__file__).resolve().parents[1]


def main():
    manifest = json.loads((ROOT / 'outputs/build-manifest.json').read_text())
    original = ROOT / 'outputs' / manifest['file']
    expected_hash = hashlib.sha256(original.read_bytes()).hexdigest()
    assert expected_hash == manifest['sha256']
    symbols = read_symbols(ROOT / 'work/build/symbols.json')
    scene_count = len(manifest['assets']['scenes'])
    tree = ET.parse(ROOT / 'play/openmsx-user/machines/SATOREINKER_MSX1_32_NTSC.xml')
    ram = tree.findall('.//RAM/mem')
    assert len(ram) == 1 and int(ram[0].get('base'), 0) == 0x8000
    assert int(ram[0].get('size'), 0) == 32768
    assert not tree.findall('.//MemoryMapper')
    assert tree.findtext('.//VDP/version') == 'TMS9918A'
    assert tree.findtext('.//VDP/vram') == '16'
    start = (ROOT / 'play/START.cmd').read_text()
    launch = (ROOT / 'play/launch.tcl').read_text()
    assert '-machine SATOREINKER_MSX1_32_NTSC' in start
    assert manifest['file'] in start and '-romtype ASCII8' in start
    assert not re.search(r'V9990|Video9000|\.(?:dsk|rpl)\b|-disk[ab]', start + launch, re.I)
    assert all(setting in launch for setting in (
        'set sound_driver SDL', 'set mute false', 'set speed 100', 'set throttle on'))
    work = ROOT / 'work/sound' / uuid.uuid4().hex[:12]
    work.mkdir(parents=True)
    private_rom = work / 'sound-test.rom'
    shutil.copy2(original, private_rom)
    wav_path = work / 'native-psg.wav'
    result = {'rom_sha256': expected_hash, 'rom_bytes': original.stat().st_size,
              'physical_hardware_tested': False,
              'launcher': {'ram_bytes': 32768, 'ram_base': '8000h',
                           'vdp': 'TMS9918A', 'vram_bytes': 16384,
                           'mapper': 'ASCII8', 'v9990_required': False,
                           'replay_disk_required': False, 'audible_driver_requested': True}}
    with OpenMSX('ntsc', work=work) as emu:
        emu.load_rom(private_rom)
        emu.run_for(3)
        emu.key(3, 2)  # Actual D matrix bit; input-only showcase activation.
        emu.run_for(.15)
        emu.key(3, 2, False)
        emu.run_for(.15)
        assert emu.read_symbol(symbols, 'mode') == 4
        emu.command('set ::snd_selected -1; set ::snd_writes {}; set ::snd_io_bad 0; '
                    'set ::snd_snapshots {}')
        wp0 = emu.command('debug set_watchpoint write_io 0xA0 {} '
                          '{set ::snd_selected $::wp_last_value}')
        # Only the module's writes count; joystick polling legitimately uses R15.
        cond = '{[reg PC] >= %d && [reg PC] < %d}' % (
            symbols['sound_init'], symbols['sound_code_end'])
        wp1 = emu.command('debug set_watchpoint write_io 0xA1 ' + cond + ' '
                          '{lappend ::snd_writes $::snd_selected; '
                          'if {$::snd_selected == 7 && ($::wp_last_value & 192) != 128} '
                          '{incr ::snd_io_bad}}')
        collect = ('{lappend ::snd_snapshots [binary encode hex '
                   '[debug read_block {PSG regs} 0 16]]}')
        bp = emu.command(f'debug set_bp {symbols["main_loop"]} {{}} {collect}')
        emu.command('soundlog start ' + tcl_word(wav_path.as_posix()))
        emu.run_for(4.5)
        emu.command('soundlog stop')
        snapshots = [bytes.fromhex(s) for s in emu.command('set ::snd_snapshots').split()]
        writes = [int(v) for v in emu.command('set ::snd_writes').split()]
        assert len(snapshots) >= 64
        assert writes and not ({14, 15} & set(writes))
        assert int(emu.command('set ::snd_io_bad')) == 0
        assert all((s[7] & 0xC0) == 0x80 for s in snapshots)
        fields = {
            'bass_periods': sorted({s[0] | s[1] << 8 for s in snapshots}),
            'percussion_periods': sorted({s[2] | s[3] << 8 for s in snapshots}),
            'noise_periods': sorted({s[6] for s in snapshots}),
            'bass_volumes': sorted({s[8] for s in snapshots}),
            'percussion_volumes': sorted({s[9] for s in snapshots}),
            'mixer_values': sorted({s[7] for s in snapshots})}
        assert all(len(v) > 1 for v in fields.values())
        emu.command(f'debug remove_bp {bp}')
        # ESC pause and resume use the same real input path as a player.
        emu.key(7, 4)
        emu.run_for(.15)
        emu.key(7, 4, False)
        emu.run_for(.15)
        assert emu.read_symbol(symbols, 'mode') == 3
        paused_regs = emu.read_block('PSG regs', 0, 16)
        assert paused_regs[8:11] == bytes(3)
        emu.key(7, 4)
        emu.run_for(.15)
        emu.key(7, 4, False)
        emu.run_for(.15)
        assert emu.read_symbol(symbols, 'mode') == 4
        assert emu.read_symbol(symbols, 'SND_RUN') == 1
        resumed = []
        for _ in range(16):
            emu.run_for(1 / 30)
            resumed.append(emu.read_block('PSG regs', 0, 16))
        assert any(s[8] or s[9] for s in resumed)
        assert len({s[8:10] for s in resumed}) > 1
        late_wave_results = []
        for scene in sorted({5, 6, 9, 10, scene_count - 1} & set(range(scene_count))):
            for name, value in (('scene', scene), ('frame', 16), ('scene_pass', 0), ('mode', 4)):
                emu.write_block('memory', symbols[name], bytes([value]))
            emu.run_for(.12)  # Finish any previously prepared frame before sampling.
            emu.command('set ::snd_late_states {}; set ::snd_late_regs {}')
            state = ('{lappend ::snd_late_states [debug read memory %d]; '
                     'lappend ::snd_late_regs [binary encode hex '
                     '[debug read_block {PSG regs} 0 16]]}') % symbols['SND_PHASE']
            late_bp = emu.command(f'debug set_bp {symbols["main_loop"]} {{}} {state}')
            emu.run_for(1.2)
            emu.command(f'debug remove_bp {late_bp}')
            phases = [int(value) for value in emu.command('set ::snd_late_states').split()]
            late_regs = [bytes.fromhex(value) for value in emu.command('set ::snd_late_regs').split()]
            increments = {(after - before) & 255 for before, after in zip(phases, phases[1:])}
            expected_increment = 64 + 4 * min(scene, 5)
            assert len(phases) >= 30 and increments == {expected_increment}
            assert emu.read_symbol(symbols, 'scene') == scene
            assert emu.read_symbol(symbols, 'SND_RUN') == 1
            assert len({regs[8:10] for regs in late_regs}) > 1
            assert all((regs[7] & 0xC0) == 0x80 for regs in late_regs)
            late_wave_results.append(dict(scene=scene, displayed_wave=scene + 1,
                fixture='RAM-seeded scene/frame16 in invincible showcase; not survival evidence',
                sampled_updates=len(phases), phase_increment=expected_increment,
                phase_increments_observed=sorted(increments),
                tempo_ceiling_preserved=True, varying_psg_volumes=True))
        writes = [int(v) for v in emu.command('set ::snd_writes').split()]
        assert not ({14, 15} & set(writes))
        assert int(emu.command('set ::snd_io_bad')) == 0
        for ident in (wp0, wp1):
            emu.command(f'debug remove_watchpoint {ident}')
        result['native_psg'] = dict(
            **fields, snapshots=len(snapshots), sound_registers_written=sorted(set(writes)),
            io_direction_violations=0, sound_writes_to_r14_r15=0,
            pause_silences_all_channels=True, resume_restarts_groove=True,
            late_wave_tempo_tests=late_wave_results,
            vram_timing_violations=emu.timing_violations(), machine=emu.machine_info())
    with wave.open(str(wav_path), 'rb') as wav:
        pcm = wav.readframes(wav.getnframes())
        assert wav.getsampwidth() == 2
        values = memoryview(pcm).cast('h')
        peak = max(abs(value) for value in values)
        nonzero = sum(value != 0 for value in values)
        assert peak > 0 and nonzero > wav.getframerate()
        result['audio'] = dict(path=str(wav_path.relative_to(ROOT)),
                               frames=wav.getnframes(), sample_rate=wav.getframerate(),
                               channels=wav.getnchannels(), peak=peak,
                               nonzero_samples=nonzero, native_pcm_verified=True,
                               subjective_listening_performed=False)
    assert hashlib.sha256(original.read_bytes()).hexdigest() == expected_hash
    result['rom_unchanged'] = True
    (ROOT / 'outputs/sound-launcher-verification.json').write_text(
        json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
