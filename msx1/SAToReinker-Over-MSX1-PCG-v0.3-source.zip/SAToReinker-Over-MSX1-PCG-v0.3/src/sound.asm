; Original PSG groove for the MSX1 PCG experiment. Pasmo syntax, no own ORG.
; sound_init: start. sound_tick: A = scene, once per rendered update.
; sound_graze: short ascending sparkle. sound_hit: stop groove, falling burst.
; Continue sound_tick after sound_hit to finish the burst. sound_stop: silence.
; All entry points preserve BC/DE/HL/IX/IY; AF is volatile. No BIOS calls.
; Owns E900..E91F. PSG channels: A bass, B percussion, C effects.
; R7 always has bit 7 = 1 and bit 6 = 0. R14/R15 are never accessed.

SND_RUN         EQU 0E900h
SND_PHASE       EQU 0E901h
SND_STEP        EQU 0E902h
SND_BASS_VOL    EQU 0E903h
SND_PERC_KIND   EQU 0E904h
SND_PERC_AGE    EQU 0E905h
SND_FX_KIND     EQU 0E906h
SND_FX_AGE      EQU 0E907h
SND_MIX        EQU 0E908h

sound_init:
    push bc
    push de
    push hl
    call sound_stop
    xor a
    ld hl,SND_RUN
    ld de,SND_RUN+1
    ld bc,31
    ld (hl),a
    ldir
    inc a
    ld (SND_RUN),a
    ld a,255
    ld (SND_PHASE),a
    ld a,15
    ld (SND_STEP),a
    pop hl
    pop de
    pop bc
    ret

sound_stop:
    push de
    xor a
    ld (SND_RUN),a
    ld (SND_FX_KIND),a
    ld e,a
    ld a,8
    call snd_write
    ld a,9
    call snd_write
    ld a,10
    call snd_write
    ld e,0BFh
    ld a,7
    call snd_write
    pop de
    ret

sound_graze:
    ld a,(SND_FX_KIND)
    or a
    ret nz
    inc a
    ld (SND_FX_KIND),a
    xor a
    ld (SND_FX_AGE),a
    ret

sound_hit:
    call sound_stop
    ld a,2
    ld (SND_FX_KIND),a
    xor a
    ld (SND_FX_AGE),a
    ret

sound_tick:
    push bc
    push de
    push hl
    ; Fractional 16th-note clock: 64..84 / 256 steps per update.
    ; At 30 updates/s this gives about 112.5..147.7 BPM, with no tempo jump.
    ; Preserve the original six-wave groove; extra waves keep its top tempo.
    cp 6
    jr c,snd_tempo_ready
    ld a,5
snd_tempo_ready:
    add a,a
    add a,a
    add a,64
    ld b,a
    ld a,0B8h
    ld (SND_MIX),a
    ld a,(SND_RUN)
    or a
    jr z,snd_effect
    ld a,(SND_PHASE)
    add a,b
    ld (SND_PHASE),a
    call c,snd_step_next
    call snd_bass
    call snd_percussion

snd_effect:
    ld a,(SND_FX_KIND)
    or a
    jr z,snd_effect_silent
    cp 2
    jr z,snd_hit_render
    ld a,(SND_FX_AGE)
    cp 4
    jr nc,snd_effect_done
    ld hl,snd_graze_period
    call snd_word_at
    ld c,4
    call snd_tone
    ld a,(SND_FX_AGE)
    ld hl,snd_graze_volume
    call snd_byte_at
    jr snd_effect_volume

snd_hit_render:
    ld a,(SND_FX_AGE)
    cp 12
    jr nc,snd_effect_done
    ld hl,snd_hit_period
    call snd_word_at
    ld c,4
    call snd_tone
    ld a,(SND_FX_AGE)
    add a,3
    ld e,a
    ld a,6
    call snd_write
    ld a,09Bh
    ld (SND_MIX),a
    ld a,(SND_FX_AGE)
    ld b,a
    ld a,15
    sub b
snd_effect_volume:
    ld e,a
    ld a,10
    call snd_write
    ld a,(SND_FX_AGE)
    inc a
    ld (SND_FX_AGE),a
    jr snd_tick_finish
snd_effect_done:
    xor a
    ld (SND_FX_KIND),a
snd_effect_silent:
    ld e,0
    ld a,10
    call snd_write
snd_tick_finish:
    ld a,(SND_MIX)
    ld e,a
    ld a,7
    call snd_write
    pop hl
    pop de
    pop bc
    ret

snd_step_next:
    ld a,(SND_STEP)
    inc a
    and 15
    ld (SND_STEP),a
    ld hl,snd_bass_period
    call snd_word_at
    ld a,h
    or l
    jr z,snd_bass_rest
    ld c,0
    call snd_tone
    ld a,13
snd_bass_rest:
    ld (SND_BASS_VOL),a
    ld a,(SND_STEP)
    ld hl,snd_drum_steps
    call snd_byte_at
    ld (SND_PERC_KIND),a
    xor a
    ld (SND_PERC_AGE),a
    ret

snd_bass:
    ld a,(SND_BASS_VOL)
    ld e,a
    sub 3
    jr nc,snd_bass_decay
    xor a
snd_bass_decay:
    ld (SND_BASS_VOL),a
    ld a,8
    jp snd_write

snd_percussion:
    ld a,(SND_PERC_AGE)
    cp 4
    jr nc,snd_drum_silent
    ld a,(SND_PERC_KIND)
    cp 1
    jr z,snd_kick
    ld e,2
    or a
    jr z,snd_noise_set
    ld e,12
snd_noise_set:
    ld a,6
    call snd_write
    ld a,0AAh
    ld (SND_MIX),a
    jr snd_drum_volume
snd_kick:
    ld a,(SND_PERC_AGE)
    ld hl,snd_kick_period
    call snd_word_at
    ld c,2
    call snd_tone
snd_drum_volume:
    ld a,(SND_PERC_KIND)
    add a,a
    add a,a
    ld b,a
    ld a,(SND_PERC_AGE)
    add a,b
    ld hl,snd_drum_volume_table
    call snd_byte_at
    ld e,a
    ld a,(SND_PERC_AGE)
    inc a
    ld (SND_PERC_AGE),a
    ld a,9
    jp snd_write
snd_drum_silent:
    ld e,0
    ld a,9
    jp snd_write

; A = index, HL = table. Byte result A, word result HL. D/E volatile.
snd_word_at:
    add a,a
    ld e,a
    ld d,0
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    ret
snd_byte_at:
    ld e,a
    ld d,0
    add hl,de
    ld a,(hl)
    ret

; HL = 12-bit period, C = first tone register (0, 2 or 4).
snd_tone:
    ld a,c
    out (0A0h),a
    ld a,l
    out (0A1h),a
    ld a,c
    inc a
    out (0A0h),a
    ld a,h
    out (0A1h),a
    ret

; A = register, E = value. The caller preserves the BIOS joystick I/O bits.
snd_write:
    out (0A0h),a
    ld a,e
    out (0A1h),a
    ret

; E minor syncopated bass, one bar. Zero is an intentional rest.
snd_bass_period:
    dw 1357,0,679,1357,0,1357,906,0
    dw 1357,0,679,1141,0,1016,906,0
; 0 = tight hat, 1 = falling-pitch kick, 2 = snare.
snd_drum_steps:
    db 1,0,0,0,2,0,1,0,1,0,1,0,2,0,0,0
snd_kick_period:
    dw 256,512,896,1200
snd_drum_volume_table:
    db 8,3,0,0, 15,11,6,0, 13,8,3,0
snd_graze_period:
    dw 112,89,67,56
snd_graze_volume:
    db 12,9,5,2
snd_hit_period:
    dw 96,128,176,240,320,432,576,736,912,1120,1376,1664
sound_code_end:
