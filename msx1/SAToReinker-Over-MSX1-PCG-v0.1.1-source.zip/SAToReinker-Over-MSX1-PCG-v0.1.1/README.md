# SAToReinker-Over MSX版 — 弾幕表現チャレンジ

**MSX1 PCG Bullet-Pattern Challenge / v0.1.1**

SAToReinker-Overの初代MSX版として、Z80とTMS9918AのPCGで、色のある弾幕をどこまで動かせるか試す独立した試作です。
**RAM 32KiB、VRAM 16KiB、ASCII8 512KiB ROM。リプレイ機能はありません。**

V9990版とは描画方式とゲーム進行が異なります。公開済みV9990版のROM・ソース・リプレイ形式は変更しません。

A standalone MSX1 version of SAToReinker-Over exploring dense, colourful bullet patterns using PCG on the Z80 and TMS9918A.
Requires 32 KiB RAM, 16 KiB VRAM and a 512 KiB ASCII8 MegaROM. It has six patterns, a small player hitbox, graze scoring,
focus movement and PSG sound. There is no replay, disk save/load or player-seeking trajectory. The V9990 version is a separate build.

## 遊ぶ

WindowsではopenMSXをインストール済みなら [play/START.cmd](play/START.cmd) を実行します。
標準以外の場所にインストールした場合は `OPENMSX_EXE` に実行ファイルの場所を設定してください。
同梱の設定は、openMSXに別途インストールされているC-BIOSを利用する**32KiB RAMの検証用MSX1構成**です。
BIOSファイル自体は同梱していません。実在する特定機種の完全な再現を意味しません。

ROMを直接使う場合は [SAToReinker-Over-MSX1-PCG-v0.1.1.rom](outputs/SAToReinker-Over-MSX1-PCG-v0.1.1.rom) を
初代MSX、RAM32KiB以上、VRAM16KiB、マッパー **ASCII8** で読み込んでください。

|操作|キーボード|ジョイスティック1|
|---|---|---|
|移動|カーソルキー|方向入力|
|開始・再挑戦|SPACE|トリガー1|
|低速移動|SHIFT|トリガー2|
|一時停止・再開|ESC|—|
|無敵の鑑賞デモ|タイトル／ゲームオーバーでD|—|
|鑑賞デモを終了してタイトルへ戻る|SPACE|トリガー1|

English controls: arrows / joystick port 1 to move; SPACE / trigger 1 to start or retry; SHIFT / trigger 2 for slow movement;
ESC to pause or resume; D at the title or game-over screen for the invincible viewing demo.
Press SPACE / trigger 1 to leave the demo, including while it is paused, and return to the title.
For the Windows launcher, extract the bundle and run `play/START.cmd` with your own openMSX installation.
Its test configuration uses externally installed C-BIOS, 32 KiB RAM and 16 KiB VRAM. No emulator or BIOS is included.

見えている自機の中心3×3ドットが当たり判定です。周囲をかすると青い火花と加点が出ます。
かすり状態を維持すると一定間隔で追加点を得られます。火花に防御効果はありません。
弾幕は６種類。各パターンを２回通過すると次へ進み、６種類の後は後半３種類を繰り返します。
画面内の菱形は弾の発生源を示す目印で、それ自体に接触判定はありません。
PSGのベースと打楽器が鳴り、進行につれてリズムが速くなります。

## PCGで弾幕を動かす仕組み

この試作では、弾道・曲線・弾同士の重なりを開発時に計算し、768フレーム分をROMに格納しています。
本体は次のPCGと配置データを復号し、自機の移動・当たり判定・スコア・サウンドをリアルタイムに処理します。
プレイ動画の再生ではなく、ROMに用意した弾幕を自分で避けるゲームです。自機を追尾する弾道はありません。

- 弾は2×2ドット。8×8のPCG１枚を16ビットの占有マスクとして扱います。
- 空白・単発・２個の重なりは固定辞書を使い、３個以上の重なりだけ動的PCGを転送します。
- 動的PCGの実パターンもROMに事前格納し、Z80上でのピクセル合成を省きます。
- 圧縮した名前テーブルをRAMで展開し、完成した裏の名前テーブルを垂直帰線に合わせて表示します。
- 動的PCGも表裏で別の番号を使い、表示中の弾の形を上書きしません。
- 弾にはハードウェアスプライトを使わないため、横一列４枚というスプライト制限による弾の欠落は起こりません。
- 自機・かすり・発生源のスプライトは、同一走査線で最大４枚に収めています。
- 当たり判定は、その更新で表示するPCGの占有マスクを参照します。

SCREEN2は横８ドットごとに２色という制約があります。弾が同じセルに集まると共通の色へ変わりますが、
重なった弾を消して負荷を下げる方式にはしていません。計算済みの弾幕を使うことで計算量を減らせる一方、
自由な追尾や、その場で新しい弾道を組み合わせる汎用エンジンとは異なる構成です。

ROMはフラッシュカートリッジ向けに正確に524,288バイトです。空きはFFで埋めています。
空き容量の有無と、CPU・VDPの転送速度の限界は別に考える必要があります。

## ビルドと検証

Python3、Pillow（資産プレビュー用）、Pasmoを利用します。
`PASMO` 環境変数でアセンブラの場所を指定できます。標準探索場所は `C:/Software/Pasmo/pasmo.exe` です。

```text
python tools/build.py
python tools/verify_and_capture.py
python tools/verify_pal.py
python tools/verify_native_decode.py
```

エミュレータ検証はそれぞれ独立したプロセスで行い、利用者のセーブディスクや他の実行中のエミュレータは使いません。
最終の測定結果はoutputs内の検証JSONを参照してください。assets内のプレビューはオフライン生成画像で、
outputs内の `*-emulator.gif` は実ROMをopenMSXで動かした画面です。鑑賞デモには画面上にDEMOと表示します。

確認した結果（openMSX 21.0、実機未検証）：

|項目|結果|
|---|---|
|RAM / VRAM|実際に32KiB / 16KiBへ制限したNTSC・PAL構成で起動・操作|
|通常プレイの高密度測定|NTSC 28.5更新/秒、PAL 25.0更新/秒（２秒の測定区間）|
|鑑賞DEMOの各弾幕|NTSC 約30更新/秒。無敵で当たり判定を省くため通常プレイ測定と区別|
|最大表示量|２×２ドットの弾309個（BRAIDED RIBBONSのピーク）|
|復号・描画|42条件で名前テーブル・PCG３領域・反対ページの保全確認|
|当たり判定|実Z80の判定ルーチン592回が期待値と一致|
|VRAM転送間隔|検証した範囲で違反０件|
|64KiB RAM|標準C-BIOS MSX1構成でも同じROMの起動・開始を確認|
|サウンド|PSG音程・音量・ノイズの変化、ポーズ消音・復帰、録音PCMの非ゼロを確認|

通常プレイの高密度測定は、検証用に場面と自機位置をRAMへ設定して行っています。
その場面まで普通に生き残った実演や、あらゆる配置で一定速度を保証する結果ではありません。
録音データの確認は発音の検証であり、音楽の主観的な試聴評価とは分けています。

アニメーション資産の割当は18個の8KiBバンクです。起動・実行用の予約分を含め176KiBを割り当て、
512KiB ROMには336KiBの空きがあります。今回は転送量と動きを先に検証できる構成にしました。

[序盤の実行GIF](outputs/wave-1-emulator.gif) · [中盤](outputs/wave-3-emulator.gif) · [高密度](outputs/wave-5-emulator.gif)

English validation: tested in openMSX with RAM limited to 32 KiB and VRAM to 16 KiB. A two-second dense normal-play sample
measured 28.5 updates/s in NTSC and 25.0 in PAL; this is not a guarantee for every frame. The GIFs show actual ROM execution
in the invincible DEMO mode, which skips collision checks and runs at about 30 updates/s in NTSC. The six patterns peak at
309 visible 2×2-pixel dots. Bullet trajectories and overlapping PCG patterns are precomputed in ROM; player movement,
collision detection and scoring run live. The measured decoder, collision and VRAM timing checks are emulator results.

この版は性能・表現の試作です。**実機での動作確認はしていません。無保証であり、すべての実機・
カートリッジ・エミュレータでの動作や、今後の更新・不具合対応を約束するものではありません。**

This is an experimental bullet-pattern rendering challenge, not a finished release or a hardware performance guarantee.
Physical hardware has not been tested. Provided as-is, without warranty; compatibility, future development and bug fixes
are not promised. It is not an official product of or endorsed by any hardware manufacturer.
