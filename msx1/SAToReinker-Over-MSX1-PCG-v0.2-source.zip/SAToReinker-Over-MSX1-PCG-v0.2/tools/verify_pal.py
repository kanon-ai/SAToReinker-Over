"""Private 32 KiB PAL ROM smoke; keyboard tests and explicitly seeded stress."""
from pathlib import Path
import hashlib
import json
import struct
import traceback

from emulator_support import OpenMSX, Profile, ROOT, prepare_profiles, read_symbols, tcl_word
from verify_native_decode import breakpoint, run_until


class Stock64Profile(Profile):
    """Select the installed stock machine, leaving the 32 KiB profiles intact."""
    def command_line(self, standard, control="stdio"):
        args = super().command_line(standard, control)
        args[args.index("-machine") + 1] = "C-BIOS_MSX1_JP"
        return args


def native_entry_hint_checks(emu, symbols, scenes):
    """Actual Z80 decode_frame + overlay with explicit RAM/CPU fixtures.

    Running the decoder first proves frame32 clears the row previously used
    for the warning. These isolated UI calls do not claim natural survival.
    """
    saved_cpu = emu.read_block("CPU regs", 0, 28)
    saved_names = emu.read_block("memory", symbols["names"], 768)
    saved_state = emu.read_block("memory", 0xE800, 0x120)
    saved_stack = emu.read_block("memory", 0xF2C0, 0x40)
    saved_masks = emu.read_block("memory", symbols["mask_ram"], 512)
    glyphs = {letter: index for index, letter in enumerate(' 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ:-', 217)}
    encoded = lambda text: bytes(glyphs[letter] for letter in text)
    cases = []
    for scene, meta in enumerate(scenes):
        if meta.get("entry_hint"):
            cases.extend((scene, frame, mode) for mode in (1, 4) for frame in (0, 31, 32))
            cases.extend((scene, 0, mode) for mode in (0, 2, 3))
        elif scene < 6:
            cases.extend((scene, 0, mode) for mode in (1, 4))
    marker = "::pal_hint_return"
    bp = breakpoint(emu, 0xF2F0, marker)
    evidence = []
    try:
        emu.write_block("memory", 0xF2E0, struct.pack("<H", 0xF2F0))
        for scene, frame, mode in cases:
            for name, value in (("scene", scene), ("frame", frame), ("mode", mode)):
                emu.write_block("memory", symbols[name], bytes([value]))
            for routine in ("decode_frame", "overlay"):
                run_until(emu, marker, f"reg PC {symbols[routine]};reg SP 62176")  # F2E0
            names = emu.read_block("memory", symbols["names"], 768)
            hint = scenes[scene].get("entry_hint", 0)
            expected = encoded({1: "FROM BELOW", 2: "FROM SIDES"}[hint]) \
                if hint and frame < 32 and mode in (1, 4) else bytes(10)
            assert names[74:84] == expected, (scene, frame, mode, names[74:84], expected)
            assert names[64:74] == bytes(10) and names[84:96] == bytes(12)
            if mode == 4:
                demo_text = encoded("DEMO SPACE:EXIT")
                assert names[9:9 + len(demo_text)] == demo_text
            evidence.append(dict(scene=scene, displayed_wave=scene + 1, frame=frame, mode=mode,
                                 expected_hint=expected.hex(), native_names=names[74:84].hex(), passed=True))
    finally:
        emu.command(f"debug remove_bp {tcl_word(bp)}")
        emu.write_block("memory", symbols["names"], saved_names)
        emu.write_block("memory", symbols["mask_ram"], saved_masks)
        emu.write_block("memory", 0xE800, saved_state)
        emu.write_block("memory", 0xF2C0, saved_stack)
        emu.write_block("CPU regs", 0, saved_cpu)
        emu.command("set pause on;debug cont")
    return {"fixture": "Native decode_frame and overlay calls with scene/frame/mode and return-stack fixtures",
            "natural_gameplay_claim": False, "cases": evidence, "passed": True}


def main():
    manifest = json.loads((ROOT / "outputs/build-manifest.json").read_text())
    frame_info = json.loads((ROOT / "assets/frame-info.json").read_text())
    scene_count = len(manifest["assets"]["scenes"])
    rom = (ROOT / "outputs" / manifest["file"]).read_bytes()
    symbols = read_symbols(ROOT / "work/build/symbols.json")
    digest = hashlib.sha256(rom).hexdigest()
    assert digest == manifest["sha256"]
    profile = prepare_profiles()
    copy = profile.directory / manifest["file"]
    copy.write_bytes(rom)  # Do not lock the developer's rebuild output.
    report = {"machine": "GRAZE_MSX1_RAM32_PAL", "bios": "externally installed C-BIOS MSX1 JP",
              "physical_hardware_tested": False, "rom_sha256": digest,
              "rom_bytes": len(rom), "results": [], "private_profile": str(profile.directory)}
    output = ROOT / "outputs/pal-verification.json"

    def check(name, passed, **evidence):
        report["results"].append({"name": name, "passed": bool(passed), **evidence})
        print(name, "PASS" if passed else "FAIL", evidence, flush=True)
        if not passed:
            raise AssertionError(name)

    try:
        with OpenMSX("pal", profile=profile) as emu:
            emu.load_rom(copy, "ASCII8")
            emu.run_for(5)
            info = emu.machine_info()
            report["environment"] = info
            read = lambda name, size=1: emu.read_symbol(symbols, name, size)
            check("physical-32KiB-RAM", info["ram_bytes"] == 32768)
            check("physical-16KiB-VRAM", info["vram_bytes"] == 16384)
            check("native-PAL-TMS9929A-config", info["machine"] == "GRAZE_MSX1_RAM32_PAL")
            check("title-boot-mode0", read("mode") == 0, mode=read("mode"))
            regs = emu.read_block("VDP regs", 0, 8)
            check("SCREEN2", regs[0] & 2 and regs[1] & 0x40, registers=list(regs))
            device = emu.command(f"lsearch -inline [debug list] {tcl_word('*' + manifest['file'])}")
            check("ROM-debug-device-found", bool(device), device=device)
            actual_hash = hashlib.sha256(emu.read_block(device, 0, 524288)).hexdigest()
            check("actual-executed-ROM-hash", actual_hash == digest, sha256=actual_hash)
            check("boot-VRAM-timing", emu.timing_violations() == 0, count=emu.timing_violations())

            def tap(row, mask, seconds=0.08):
                emu.key(row, mask, True)
                emu.run_for(seconds)
                emu.key(row, mask, False)
                emu.run_for(0.04)

            tap(8, 1)
            check("space-start", read("mode") == 1, mode=read("mode"))
            for name, mask, axis, sign in (("left", 0x10, "player_x", -1),
                                            ("right", 0x80, "player_x", 1),
                                            ("up", 0x20, "player_y", -1),
                                            ("down", 0x40, "player_y", 1)):
                before = read(axis)
                tap(8, mask)
                after = read(axis)
                check("keyboard-" + name, (after - before) * sign > 0,
                      before=before, after=after, mode=read("mode"))

            # Equal-duration input windows; movement comes from real key input.
            before = read("player_x")
            tap(8, 0x80, 0.16)
            normal_distance = read("player_x") - before
            emu.key(6, 1, True)  # Shift
            emu.run_for(0.04)
            before = read("player_x")
            tap(8, 0x80, 0.16)
            focus_distance = read("player_x") - before
            emu.key(6, 1, False)
            emu.run_for(0.04)
            check("shift-focus-slower", 0 < focus_distance < normal_distance,
                  normal_pixels=normal_distance, focus_pixels=focus_distance, mode=read("mode"))

            tap(7, 4)
            check("ESC-pauses", read("mode") == 3, mode=read("mode"))
            frame, score = read("frame"), emu.read_block("memory", symbols["score"], 6)
            emu.run_for(0.24)
            check("pause-freezes-game-state", read("frame") == frame and
                  emu.read_block("memory", symbols["score"], 6) == score, frame=read("frame"))
            tap(7, 4)
            check("ESC-resumes", read("mode") == 1, mode=read("mode"))
            check("ESC-resumes-sound-driver", read("SND_RUN") == 1, sound_run=read("SND_RUN"))
            check("keyboard-smoke-VRAM-timing", emu.timing_violations() == 0,
                  count=emu.timing_violations())

            # Explicit synthetic setup, not player survival or a sample replay.
            # Mode4 disables collision death; scene4/frame60 selects dense PCG.
            for name, value in (("mode", 4), ("scene", 4), ("frame", 60),
                                ("scene_pass", 0), ("old_keys", 0)):
                emu.write_block("memory", symbols[name], bytes([value]))
            emu.run_for(0.16)  # Let any previously prepared frame complete.
            start_time = float(emu.command("machine_info time"))
            start_count = read("update_count", 2)
            emu.run_for(1.6)
            end_time = float(emu.command("machine_info time"))
            count = (read("update_count", 2) - start_count) & 65535
            fps = count / (end_time - start_time)
            report["stress"] = {"scenario": "RAM-seeded scene4/frame60, invincible showcase mode4",
                                "player_survival_claim": False, "updates": count,
                                "emulated_seconds": end_time - start_time, "updates_per_second": fps,
                                "final_scene": read("scene"), "final_frame": read("frame")}
            check("seeded-dense-scene-progresses", count > 0 and read("scene") == 4,
                  updates=count, measured_updates_per_second=round(fps, 3))
            check("seeded-dense-scene-VRAM-timing", emu.timing_violations() == 0,
                  count=emu.timing_violations())

            # Every generated wave, including two-digit HUD values and the
            # final bank region, is exercised with explicit peak-frame setup.
            report["all_wave_peak_stress"] = []
            for target_scene in range(scene_count):
                records = [entry for entry in frame_info if entry["scene"] == target_scene]
                peak = max(records, key=lambda entry: entry["dots"])
                for name, value in (("mode", 4), ("scene", target_scene), ("frame", peak["frame"]),
                                    ("scene_pass", 0), ("old_keys", 0)):
                    emu.write_block("memory", symbols[name], bytes([value]))
                emu.run_for(.16)
                t0 = float(emu.command("machine_info time"))
                n0 = read("update_count", 2)
                emu.run_for(.8)
                elapsed = float(emu.command("machine_info time")) - t0
                updates = (read("update_count", 2) - n0) & 65535
                regs = emu.read_block("VDP regs", 0, 8)
                # Read the displayed name table: the back RAM table can be
                # halfway through a decode when an emulated-time timer fires.
                display_base = (regs[2] & 15) * 0x400
                hud = list(emu.read_block("physical VRAM", display_base + 59, 2))
                expected_hud = [218 + (target_scene + 1) // 10, 218 + (target_scene + 1) % 10]
                sat_base = (regs[5] & 127) * 128
                sat = emu.read_block("physical VRAM", sat_base, 20)
                emitters = emu.read_block("memory", symbols["wave_emitters"] + target_scene * 5, 5)
                assert emitters[0] <= 2
                asset_emitters = manifest["assets"]["scenes"][target_scene]["emitters"]
                assert emitters[0] == len(asset_emitters)
                assert [list(emitters[1 + i * 2:3 + i * 2])
                        for i in range(emitters[0])] == asset_emitters
                expected_marker_rows = []
                for emitter in range(emitters[0]):
                    x, y = emitters[1 + emitter * 2:3 + emitter * 2]
                    actual = sat[8 + emitter * 4:11 + emitter * 4]
                    assert actual == bytes([(y - 8) & 255, (x - 7) & 255, 8])
                    expected_marker_rows.append(list(actual))
                assert sat[8 + emitters[0] * 4] == 208
                evidence = {"scene": target_scene, "displayed_wave": target_scene + 1,
                            "fixture": "RAM-seeded peak frame; invincible mode; not survival evidence",
                            "peak_frame": peak["frame"], "peak_dots": peak["dots"],
                            "peak_packet_bank": peak["bank"], "updates": updates,
                            "emulated_seconds": elapsed, "updates_per_second": updates / elapsed,
                            "hud_tiles": hud, "emitter_markers": expected_marker_rows}
                report["all_wave_peak_stress"].append(evidence)
                check(f"wave{target_scene+1:02}-PAL-peak-HUD-markers",
                      read("scene") == target_scene and read("mode") == 4 and updates > 0
                      and hud == expected_hud, updates=updates,
                      measured_updates_per_second=round(updates / elapsed, 3),
                      hud=hud, emitter_count=emitters[0])
            check("all-wave-PAL-VRAM-timing", emu.timing_violations() == 0,
                  count=emu.timing_violations())
            # Boundaries execute actual next_frame code, not Python progression.
            for from_scene, loop_delta, label in (
                    (5, 0, "original-wave06-continues-to-wave07"),
                    (scene_count - 1, 1, "last-wave-loops-to-expanded-wave07")):
                loop_before = read("loop_count")
                for name, value in (("mode", 4), ("scene", from_scene), ("frame", 126),
                                    ("scene_pass", 1), ("old_keys", 0)):
                    emu.write_block("memory", symbols[name], bytes([value]))
                emu.run_for(.32)
                check(label, read("scene") == 6 and
                      read("loop_count") == ((loop_before + loop_delta) & 255),
                      final_scene=read("scene"), final_frame=read("frame"), loop_count=read("loop_count"))
            for name, value in (("mode", 0), ("scene", 9), ("frame", 32), ("old_keys", 0)):
                emu.write_block("memory", symbols[name], bytes([value]))
            emu.run_for(.24)
            regs = emu.read_block("VDP regs", 0, 8)
            title_digits = list(emu.read_block("physical VRAM", (regs[2] & 15) * 0x400 + 59, 2))
            check("title-two-digit-wave10-HUD", read("mode") == 0 and read("scene") == 9
                  and title_digits == [219, 218], hud=title_digits)
            report["entry_hint_tests"] = native_entry_hint_checks(emu, symbols, manifest["assets"]["scenes"])
            check("entry-hints-native-decode-and-overlay", report["entry_hint_tests"]["passed"],
                  cases=len(report["entry_hint_tests"]["cases"]))

            def play_stress(emu, standard):
                # Scene4's left gap keeps the ordinary 3x3 core clear while
                # normal collision/graze work remains enabled. This is an
                # injected benchmark state, not a natural survival record.
                for name, value in (("mode", 1), ("scene", 4), ("frame", 20),
                                    ("scene_pass", 0), ("player_x", 8), ("player_y", 180),
                                    ("old_keys", 0)):
                    emu.write_block("memory", symbols[name], bytes([value]))
                emu.run_for(0.12)
                get = lambda name, size=1: emu.read_symbol(symbols, name, size)
                check(standard + "-normal-stress-active", get("mode") == 1, mode=get("mode"))
                t0 = float(emu.command("machine_info time"))
                n0, f0 = get("update_count", 2), get("frame")
                emu.run_for(2.0)
                elapsed = float(emu.command("machine_info time")) - t0
                updates = (get("update_count", 2) - n0) & 65535
                measured = updates / elapsed
                evidence = {"scenario": "RAM-seeded normal mode1 scene4/frame20, player(8,180)",
                            "natural_survival_claim": False, "collision_and_graze_enabled": True,
                            "updates": updates, "emulated_seconds": elapsed,
                            "updates_per_second": measured, "start_frame": f0,
                            "final_frame": get("frame"), "final_scene": get("scene"),
                            "final_mode": get("mode"), "VRAM_timing_violations": emu.timing_violations()}
                report.setdefault("normal_play_stress", {})[standard] = evidence
                check(standard + "-normal-stress-no-hit", get("mode") == 1 and get("scene") == 4,
                      mode=get("mode"), first_frame=f0, last_frame=get("frame"))
                check(standard + "-normal-stress-progresses", updates > 0,
                      updates=updates, measured_updates_per_second=round(measured, 3))
                check(standard + "-normal-stress-VRAM-timing", emu.timing_violations() == 0,
                      count=emu.timing_violations())

            play_stress(emu, "pal")

        with OpenMSX("ntsc") as emu:
            ntsc_copy = emu.profile.directory / manifest["file"]
            ntsc_copy.write_bytes(rom)
            emu.load_rom(ntsc_copy, "ASCII8")
            emu.run_for(5)
            check("ntsc-normal-stress-32KiB-RAM", emu.machine_info()["ram_bytes"] == 32768)
            play_stress(emu, "ntsc")

        # Separate compatibility smoke on the installed stock 64 KiB C-BIOS
        # machine. The private profile's 32 KiB XML files remain unchanged and
        # are not selected for this run.
        stock_profile = Stock64Profile(**vars(prepare_profiles()))
        stock_copy = stock_profile.directory / manifest["file"]
        stock_copy.write_bytes(rom)
        with OpenMSX("ntsc", profile=stock_profile) as emu:
            emu.load_rom(stock_copy, "ASCII8")
            emu.run_for(5)
            stock_info = emu.machine_info()
            report["stock_64KiB_smoke"] = stock_info
            check("stock64-machine", stock_info["machine"] == "C-BIOS_MSX1_JP")
            check("stock64-native-RAM", stock_info["ram_bytes"] == 65536,
                  bytes=stock_info["ram_bytes"])
            check("stock64-title", emu.read_symbol(symbols, "mode") == 0)
            device = emu.command(f"lsearch -inline [debug list] {tcl_word('*' + manifest['file'])}")
            stock_hash = hashlib.sha256(emu.read_block(device, 0, 524288)).hexdigest()
            check("stock64-actual-ROM-hash", stock_hash == digest, sha256=stock_hash)
            emu.key(8, 1, True)
            emu.run_for(0.1)
            emu.key(8, 1, False)
            emu.run_for(0.1)
            check("stock64-space-start", emu.read_symbol(symbols, "mode") == 1)
            check("stock64-VRAM-timing", emu.timing_violations() == 0, count=emu.timing_violations())
        report["passed"] = True
    except BaseException as exc:
        report["passed"] = False
        report["error"] = str(exc)
        report["traceback"] = traceback.format_exc()
        raise
    finally:
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
