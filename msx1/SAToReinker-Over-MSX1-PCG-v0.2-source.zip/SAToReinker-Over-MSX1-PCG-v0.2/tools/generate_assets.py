"""Build deterministic SCREEN 2 PCG choreography for the MSX1 experiment.

Bit 0 of a mask is the top-left 2x2-pixel dot; bits advance left-to-right,
then top-to-bottom. All animation packets are self-contained. This is an
offline asset generator, not a PC gameplay implementation.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import struct
from extra_waves import CANDIDATES, SELECTED, generate as extra_choreography

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
WIDTH, HEIGHT, FRAMES = 256, 192, 128
BANK_BYTES, FIRST_BANK, MAX_BANKS = 8192, 4, 60
DYNAMIC_FIRST, DYNAMIC_LIMIT = 153, 32
LEGACY_PACKET_SHA256 = "928aff40073c387e1cfb1e57fcedef6a964c09dd7fdaa500d0c74956449d975c"
PALETTE = [
    (0, 0, 0), (0, 0, 0), (33, 200, 66), (94, 220, 120),
    (84, 85, 237), (125, 118, 252), (212, 82, 77), (66, 235, 245),
    (252, 85, 84), (255, 121, 120), (212, 193, 84), (230, 206, 128),
    (33, 176, 59), (201, 91, 186), (204, 204, 204), (255, 255, 255),
]
SCENES = [
    ("LUNAR FAN", "Seven turning fans open from the northern edge."),
    ("TWIN GALAXIES", "Counter-rotating paired radial spirals."),
    ("SINE LOOM", "Alternating cyan and magenta sine curtains."),
    ("MIRROR WINGS", "Two wide fans weave through one another."),
    ("BRAIDED RIBBONS", "Twelve narrow streams braid into four ribbons."),
    ("MANDALA OVER", "Rotating radial rings and a crossing outer weave."),
]
LEGACY_SCENES = list(SCENES)
SCENES += [(wave.name, wave.description) for wave in SELECTED]
EMITTERS = [(), ((82, 88), (174, 88)), (), (), (), ((128, 89),)]
EMITTERS += [wave.emitters for wave in SELECTED]
ENTRY_HINTS = [0] * 6 + [1 if wave.family == "fountain" else 2 if wave.family == "side" else 0 for wave in SELECTED]


def choreography(scene: int, frame: int):
    """Yield physical dot top-left positions and one of two colour families."""
    if scene >= 6:
        yield from extra_choreography(SELECTED[scene - 6], frame)
        return
    if scene == 0:
        for wave, born in enumerate(range(6, 55, 8)):
            age = frame - born
            if age < 0:
                continue
            swivel = 0.14 * math.sin(wave * 0.8)
            for arm in range(13):
                angle = (arm - 6) * 0.105 + swivel
                speed = 3.25 + (wave & 1) * 0.16
                yield 128 + math.sin(angle) * age * speed, 19 + math.cos(angle) * age * speed, wave & 1
    elif scene == 1:
        for wave, born in enumerate(range(5, 54, 4)):
            age = frame - born
            if age < 0:
                continue
            for side, cx in enumerate((82, 174)):
                for arm in range(6):
                    theta = arm * math.tau / 6 + (wave * 0.23) * (1 if side == 0 else -1)
                    radius = 4.2 * age
                    yield cx + math.cos(theta) * radius, 88 + math.sin(theta) * radius, side
    elif scene == 2:
        for stream in range(9):
            for born in range(4, 57, 3):
                age = frame - born
                if age < 0:
                    continue
                x = 23 + stream * 26 + 18 * math.sin(age * 0.092 + stream * 0.7)
                yield x, 19 + age * 3.0, stream & 1
    elif scene == 3:
        for wave, born in enumerate(range(4, 57, 4)):
            age = frame - born
            if age < 0:
                continue
            for side, cx in enumerate((38, 218)):
                for arm in range(12):
                    angle = (arm - 5.5) * 0.075 + 0.32 * (1 if side == 0 else -1)
                    angle += math.sin(wave * 0.49) * 0.13
                    yield cx + math.sin(angle) * age * 3.7, 19 + math.cos(angle) * age * 3.7, side
    elif scene == 4:
        for strand, cx in enumerate((43, 100, 157, 214)):
            for born in range(4, 57, 2):
                age = frame - born
                if age < 0:
                    continue
                phase = age * 0.092 + strand * math.pi
                x = cx + math.sin(phase) * 26
                for ribbon in range(3):
                    yield x + (ribbon - 1) * 4, 19 + age * 3.05, strand & 1
    else:
        for wave, born in enumerate(range(4, 55, 3)):
            age = frame - born
            if age < 0:
                continue
            for arm in range(24):
                theta = arm * math.tau / 24 + wave * 0.093
                radius = 4.25 * age
                yield 128 + math.cos(theta) * radius, 89 + math.sin(theta) * radius, wave & 1
        for side in range(2):
            for born in range(4, 49, 4):
                age = frame - born
                if age < 0:
                    continue
                for lane in range(3):
                    x = (9 if side == 0 else 245) + (1 if side == 0 else -1) * age * 2.3
                    y = 22 + age * 3.0 + lane * 5
                    yield x, y, side


def mask_pattern(mask: int) -> bytes:
    pattern = bytearray()
    for row in range(4):
        value = 0
        for column in range(4):
            if mask & (1 << (row * 4 + column)):
                value |= 3 << (6 - column * 2)
        pattern.extend((value, value))
    return bytes(pattern)


STATIC_MASKS = [0] + [1 << b for b in range(16)] * 2
STATIC_MASKS += [(1 << a) | (1 << b) for a, b in itertools.combinations(range(16), 2)]
DOUBLE_INDICES = {m: i for i, m in enumerate(STATIC_MASKS) if i >= 33}
assert len(STATIC_MASKS) == DYNAMIC_FIRST


def build_static():
    patterns = bytearray(2048)
    colors = bytearray(2048)
    for index in range(256):
        if index < len(STATIC_MASKS):
            patterns[index * 8:index * 8 + 8] = mask_pattern(STATIC_MASKS[index])
        if 1 <= index <= 16:
            top, bottom = 15, 13
        elif 17 <= index <= 32:
            top, bottom = 7, 5
        elif 33 <= index <= 152:
            top, bottom = 15, 11
        else:
            top, bottom = 15, 7
        colors[index * 8:index * 8 + 8] = bytes([top << 4, bottom << 4] * 4)
    return bytes(patterns), bytes(colors)


def encode_names(names: bytes) -> bytes:
    encoded = bytearray()
    i = 0
    while i < len(names):
        if names[i] == 0:
            end = i + 1
            while end < len(names) and names[end] == 0 and end - i < 128:
                end += 1
            encoded.append(0x80 | (end - i - 1))
        else:
            end = i + 1
            while end < len(names) and names[end] != 0 and end - i < 127:
                end += 1
            encoded.append(end - i)
            encoded.extend(names[i:end])
        i = end
    encoded.append(0)
    return bytes(encoded)


def decode_packet(packet: bytes):
    dynamic_count = packet[0]
    assert dynamic_count <= DYNAMIC_LIMIT
    masks = []
    cursor = 1
    for _ in range(dynamic_count):
        mask = struct.unpack_from("<H", packet, cursor)[0]
        assert packet[cursor + 2:cursor + 10] == mask_pattern(mask)
        masks.append(mask)
        cursor += 10
    names = bytearray()
    while True:
        token = packet[cursor]
        cursor += 1
        if token == 0:
            break
        if token & 128:
            names.extend(bytes((token & 127) + 1))
        else:
            names.extend(packet[cursor:cursor + token])
            cursor += token
    assert cursor == len(packet)
    assert len(names) == 768
    return masks, bytes(names)


def frame_packet(scene: int, frame: int, extra=None):
    cells = [0] * 768
    families = [0] * 768
    dots = set()
    source = extra_choreography(extra, frame) if extra is not None else choreography(scene, frame)
    for x, y, color in source:
        x = int(round(x / 2)) * 2
        y = int(round(y / 2)) * 2
        if not (4 <= x <= 250 and 24 <= y <= 182):
            continue
        dots.add((x, y))
        cell = (y // 8) * 32 + x // 8
        bit = ((y & 7) // 2) * 4 + ((x & 7) // 2)
        cells[cell] |= 1 << bit
        families[cell] = color
    dynamic_masks = sorted(set(mask for mask in cells if mask.bit_count() >= 3))
    if len(dynamic_masks) > DYNAMIC_LIMIT:
        raise RuntimeError(f"scene {scene}, frame {frame}: {len(dynamic_masks)} dynamic masks exceed 32")
    dynamic_indices = {mask: DYNAMIC_FIRST + i for i, mask in enumerate(dynamic_masks)}
    names = bytearray(768)
    for i, mask in enumerate(cells):
        count = mask.bit_count()
        if count == 1:
            names[i] = mask.bit_length() + families[i] * 16
        elif count == 2:
            names[i] = DOUBLE_INDICES[mask]
        elif count >= 3:
            names[i] = dynamic_indices[mask]
    packet = bytes([len(dynamic_masks)])
    packet += b"".join(struct.pack("<H", mask) + mask_pattern(mask) for mask in dynamic_masks)
    packet += encode_names(names)
    decoded_masks, decoded_names = decode_packet(packet)
    assert decoded_masks == dynamic_masks and decoded_names == names
    all_masks = STATIC_MASKS + dynamic_masks
    assert all(all_masks[index] == cells[i] for i, index in enumerate(names))
    assert not any(names[:96]) and not any(names[736:])
    assert sum(m.bit_count() for m in cells) == len(dots)
    return packet, bytes(names), dynamic_masks, len(dots)


def preview(frames, patterns, colors):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    rendered = []
    contact = Image.new("RGB", (256 * 3, 216 * ((len(frames) + 2) // 3)), (5, 5, 10))
    preview_scenes = sorted({i for i in (0, 4, 6, 8, 10, 14, 20, 26, 30, len(frames)-1) if i < len(frames)})
    for scene, scene_frames in enumerate(frames):
        peak = max(range(FRAMES), key=lambda f: scene_frames[f][3])
        sample_frames = set(range(0, FRAMES, 4)) if scene in preview_scenes else set()
        for frame in sorted(sample_frames | {peak}):
            _, names, dynamic, _ = scene_frames[frame]
            tiledata = bytearray(patterns)
            for i, mask in enumerate(dynamic):
                tiledata[(DYNAMIC_FIRST + i) * 8:(DYNAMIC_FIRST + i + 1) * 8] = mask_pattern(mask)
            im = Image.new("RGB", (256, 216), (0, 0, 0))
            px = im.load()
            for cell, index in enumerate(names):
                if not index:
                    continue
                cx, cy = cell % 32 * 8, cell // 32 * 8
                for row in range(8):
                    bits = tiledata[index * 8 + row]
                    color = PALETTE[colors[index * 8 + row] >> 4]
                    for col in range(8):
                        if bits & (128 >> col):
                            px[cx + col, cy + row] = color
            draw = ImageDraw.Draw(im)
            draw.text((5, 3), f"{scene + 1:02} {SCENES[scene][0]}", fill=(160, 175, 210))
            draw.text((5, 196), "OFFLINE PCG PREVIEW - NOT EMULATOR", fill=(160, 160, 160))
            if frame == peak:
                contact.paste(im, ((scene % 3) * 256, (scene // 3) * 216))
            if frame in sample_frames:
                rendered.append(im)
    contact.save(ASSETS / "pcg-preview-contact.png")
    for part, y in enumerate(range(0, contact.height, 864), 1):
        contact.crop((0, y, contact.width, min(y+864, contact.height))).save(ASSETS / f"pcg-preview-contact-{part:02}.png")
    rendered[0].save(ASSETS / "pcg-preview.gif", save_all=True, append_images=rendered[1:],
                     duration=160, loop=0, optimize=False, disposal=2)
    return {"gif": "pcg-preview.gif", "contact_sheet": "pcg-preview-contact.png",
            "overview_wave_indices": preview_scenes,
            "kind": "Offline generated asset preview; not an emulator capture."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-preview", action="store_true")
    parser.add_argument("--evaluate-candidates", action="store_true")
    args = parser.parse_args()
    ASSETS.mkdir(parents=True, exist_ok=True)
    if args.evaluate_candidates:
        evaluation = []
        for wave in CANDIDATES:
            result = {"name": wave.name, "family": wave.family, "emitters": wave.emitters}
            try:
                frames = [frame_packet(6, frame, extra=wave) for frame in range(FRAMES)]
                assert frames[0][3] == frames[-1][3] == 0, "Nonempty endpoints"
                result.update(valid=True, peak_dots=max(f[3] for f in frames),
                              peak_dynamic_masks=max(len(f[2]) for f in frames),
                              payload_bytes=sum(len(f[0]) for f in frames),
                              packet_lengths=[len(f[0]) for f in frames],
                              packet_sha256=hashlib.sha256(b"".join(f[0] for f in frames)).hexdigest())
            except (RuntimeError, AssertionError) as exc:
                result.update(valid=False, reason=str(exc))
            evaluation.append(result)
            print(json.dumps({k:v for k,v in result.items() if k != "packet_lengths"}))
        (ASSETS / "candidate-evaluation.json").write_text(json.dumps(evaluation, indent=2) + "\n", encoding="utf-8")
        return
    patterns, colors = build_static()
    all_frames = [[frame_packet(scene, frame) for frame in range(FRAMES)] for scene in range(len(SCENES))]
    legacy_hash = hashlib.sha256(b"".join(f[0] for frames in all_frames[:6] for f in frames)).hexdigest()
    assert legacy_hash == LEGACY_PACKET_SHA256, "Original six waves changed"
    assert len(SCENES) <= 44, "Runtime frame-index capacity exceeded"
    stream = bytearray()
    index = bytearray()
    frame_info = []
    scenes = []
    payload = 0
    for scene, frames in enumerate(all_frames):
        assert frames[0][3] == frames[-1][3] == 0, f"scene {scene} must join through empty frames"
        for frame, (packet, names, dynamic, dots) in enumerate(frames):
            assert len(packet) <= BANK_BYTES
            offset = len(stream) % BANK_BYTES
            if offset + len(packet) > BANK_BYTES:
                stream.extend(b"\xff" * (BANK_BYTES - offset))
                offset = 0
            bank = FIRST_BANK + len(stream) // BANK_BYTES
            assert bank < FIRST_BANK + MAX_BANKS
            address = 0x6000 + offset
            index.extend(struct.pack("<BH", bank, address))
            stream.extend(packet)
            payload += len(packet)
            frame_info.append({"scene": scene, "frame": frame, "bank": bank,
                               "address": address, "length": len(packet), "dots": dots,
                               "dynamic_masks": len(dynamic)})
        scenes.append({"index": scene, "name": SCENES[scene][0], "description": SCENES[scene][1],
                       "first_frame": scene * FRAMES, "frames": FRAMES,
                       "peak_dots": max(f[3] for f in frames),
                       "peak_dynamic_masks": max(len(f[2]) for f in frames),
                       "payload_bytes": sum(len(f[0]) for f in frames),
                       "peak_frame": max(range(FRAMES), key=lambda f: frames[f][3]),
                       "emitters": EMITTERS[scene],
                       "entry_hint": ENTRY_HINTS[scene],
                       "packet_sha256": hashlib.sha256(b"".join(f[0] for f in frames)).hexdigest()})
    if len(stream) % BANK_BYTES:
        stream.extend(b"\xff" * (BANK_BYTES - len(stream) % BANK_BYTES))
    assert len(stream) <= MAX_BANKS * BANK_BYTES
    for n, expected in enumerate(frame_info):
        bank, address = struct.unpack_from("<BH", index, n * 3)
        offset = (bank - FIRST_BANK) * BANK_BYTES + address - 0x6000
        packet = bytes(stream[offset:offset + expected["length"]])
        assert packet == all_frames[expected["scene"]][expected["frame"]][0]
        decode_packet(packet)
        assert address + len(packet) <= 0x8000
    (ASSETS / "base-patterns.bin").write_bytes(patterns)
    (ASSETS / "base-colors.bin").write_bytes(colors)
    (ASSETS / "base-masks.bin").write_bytes(struct.pack("<153H", *STATIC_MASKS))
    (ASSETS / "stream.bin").write_bytes(stream)
    (ASSETS / "index.bin").write_bytes(index)
    wave_asm = ["; Generated by tools/generate_assets.py. Each emitter entry is count,x1,y1,x2,y2.",
                f"WAVE_COUNT equ {len(SCENES)}", "WAVE_LOOP_START equ 6", "wave_emitters:"]
    for scene, emitters in enumerate(EMITTERS):
        values = [len(emitters)] + [coordinate for point in emitters for coordinate in point]
        values.extend([0] * (5 - len(values)))
        wave_asm.append("    db " + ",".join(map(str, values)) + " ; " + str(scene + 1) + " " + SCENES[scene][0])
    assert len(ENTRY_HINTS) == len(SCENES) and all(value in (0, 1, 2) for value in ENTRY_HINTS)
    wave_asm.extend(["wave_entry_hints:", "    db " + ",".join(map(str, ENTRY_HINTS)) + " ; 0=none,1=BELOW,2=SIDES"])
    (ASSETS / "waves.inc").write_text("\n".join(wave_asm) + "\n", encoding="ascii")
    (ASSETS / "frame-info.json").write_text(json.dumps(frame_info, indent=2) + "\n", encoding="utf-8")
    info = {"generator": "tools/generate_assets.py", "width": WIDTH, "height": HEIGHT,
            "frames_per_scene": FRAMES, "total_frames": len(frame_info), "scenes": scenes,
            "mask_order": "bit0 top-left 2x2 dot; four dots across, four rows; little-endian u16",
            "dynamic_indices_page0": [153, 184], "dynamic_indices_page1": [185, 216],
            "packet_format": "u8 dynamic_count; count*(u16LE mask + 8 ready PCG bytes); RLE768 names; 0 terminator",
            "dynamic_pattern_bytes_precomputed": True,
            "rle": "1..127 literal length; 128..255 zero run length=(token&127)+1",
            "index_format": "u8 ASCII8 bank; u16LE CPU address in 6000..7FFF",
            "first_stream_bank": FIRST_BANK, "stream_banks": len(stream) // BANK_BYTES,
            "packet_payload_bytes": payload, "bank_padding_bytes": len(stream) - payload,
            "stream_bytes": len(stream), "index_bytes": len(index),
            "estimated_used_rom_bytes_including_reserved_banks": FIRST_BANK * BANK_BYTES + len(stream),
            "rom_limit_bytes": 512 * 1024,
            "wave_count": len(SCENES), "wave_loop_start": 6,
            "free_stream_bytes": MAX_BANKS * BANK_BYTES - len(stream),
            "unused_tail_bytes": (MAX_BANKS * BANK_BYTES) - (frame_info[-1]["bank"] - FIRST_BANK)*BANK_BYTES - (frame_info[-1]["address"] - 0x6000) - frame_info[-1]["length"],
            "legacy_packet_sha256": legacy_hash,
            "legacy_packets_preserved": True,
            "candidate_waves_evaluated": len(CANDIDATES),
            "selected_additional_wave_names": [wave.name for wave in SELECTED],
            "omitted_candidate_names": [wave.name for wave in CANDIDATES if wave not in SELECTED],
            "capacity_note": "All 42 candidates meet the 32-dynamic-PCG limit. 31 additions selected with all 11 trajectory families represented. The 32 cheapest candidates plus the original packets need 496993 bytes even without bank padding, exceeding the 491520-byte stream budget.",
            "validation": f"All {len(frame_info)} packets decoded and compared; every visible dot retained; dynamic dictionaries <=32; packets do not cross banks; index round-trip checked; scene endpoints empty."}
    if not args.no_preview:
        info["preview"] = preview(all_frames, patterns, colors)
    (ASSETS / "scenes.json").write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
