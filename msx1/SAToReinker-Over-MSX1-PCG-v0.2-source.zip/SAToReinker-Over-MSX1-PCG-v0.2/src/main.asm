; SAToReinker-Over MSX1 PCG Challenge. Native Z80, TMS9918A, no replay.
; Code copied to 8000-DFFF; only physical RAM 8000-FFFF is required.
; ROM choreographs the bullets; the player, collision, graze and sound are live.
    org 08000h
    jp main

names       equ 0E000h
mask_ram    equ 0E400h
pcg_scratch equ 0E600h
sat_ram     equ 0E680h
mode        equ 0E800h ; 0 title,1 play,2 hit,3 pause,4 invincible showcase
page        equ 0E801h ; page being prepared
scene       equ 0E802h
frame       equ 0E803h
scene_pass  equ 0E804h
player_x    equ 0E805h
player_y    equ 0E806h
keys        equ 0E807h
old_keys    equ 0E808h
edges       equ 0E809h
spark       equ 0E80Ah
graze_gate  equ 0E80Bh
score       equ 0E810h ; six decimal digits, least significant first
high_score  equ 0E818h
update_count equ 0E820h
dyn_id      equ 0E822h
dyn_count   equ 0E823h
dyn_offset  equ 0E824h
previous_mode equ 0E825h
hit_x       equ 0E826h
hit_y       equ 0E827h
query_x     equ 0E828h
query_y     equ 0E829h
move_speed  equ 0E82Ah
score_tick  equ 0E82Bh
loop_count  equ 0E82Ch
last_graze  equ 0E82Dh
saved_sp    equ 0E82Eh

main:
    di
    ld hl,0E000h
    ld de,0E001h
    ld bc,011FFh
    ld (hl),0
    ldir
    call video_init
    call sound_init
    call reset_run
    xor a
    ld (mode),a
main_loop:
    call input_read
    ld (keys),a
    ld b,a
    ld a,(old_keys)
    cpl
    and b
    ld (edges),a
    ld a,b
    ld (old_keys),a
    ld a,(mode)
    cp 1
    jr z,active_input
    cp 4
    jr z,demo_input
    cp 3
    jr z,paused_input
    ld a,(edges)
    bit 4,a
    jr z,check_showcase
    call reset_run
    jr input_done
check_showcase:
    bit 7,a
    jr z,input_done
    call reset_run
    ld a,4
    ld (mode),a
    jr input_done
demo_input:
    ld a,(edges)
    bit 4,a
    jr z,active_input
demo_exit:
    ; Use a press edge so holding trigger does not start a new run on return.
    call reset_run
    xor a
    ld (mode),a
    jr input_done
active_input:
    ld a,(edges)
    bit 6,a
    jr z,input_done
    ld a,(mode)
    ld (previous_mode),a
    ld a,3
    ld (mode),a
    call sound_stop
    jr input_done
paused_input:
    ld a,(previous_mode)
    cp 4
    jr nz,paused_resume
    ld a,(edges)
    bit 4,a
    jr nz,demo_exit
paused_resume:
    ld a,(edges)
    bit 6,a
    jr z,input_done
    ld a,(previous_mode)
    ld (mode),a
    call sound_init
input_done:
    ld a,(mode)
    cp 1
    call z,move_player
    ld a,(mode)
    cp 4
    call z,move_player
    call decode_frame
frame_decoded:
    ld a,(mode)
    cp 1
    call z,collisions
    ld a,(mode)
    cp 1
    jr z,active_score
    cp 4
    jr nz,skip_score
active_score:
    ld a,1
    call add_score
skip_score:
    call overlay
    call prepare_sprite
    ; Complete the back name table and SAT before the display-page change.
    ld hl,names
    ld de,01800h
    ld a,(page)
    or a
    jr z,name_dest
    ld de,01C00h
name_dest:
    ld bc,768
    call vram_write
    ld de,01B00h
    ld a,(page)
    or a
    jr z,sat_dest
    ld e,080h
sat_dest:
    ld hl,sat_ram
    ld bc,20
    call vram_write
    ; Two vertical events: 30 updates NTSC / 25 PAL if the work fits 2 fields.
    ; Reading status acknowledges the event. No interrupts race the two-port latch.
    call wait_vblank
    call wait_vblank
    ld a,(page)
    add a,6
    ld b,2
    call vdp_reg
frame_committed:
    ld a,(page)
    add a,036h
    ld b,5
    call vdp_reg
    ld a,(page)
    xor 1
    ld (page),a
    ld hl,(update_count)
    inc hl
    ld (update_count),hl
    ld a,(mode)
    cp 3
    jp z,main_loop
    ld a,(scene)
    call sound_tick
    ld a,(spark)
    or a
    jr z,no_spark_tick
    dec a
    ld (spark),a
no_spark_tick:
    ld a,(mode)
    cp 2
    jp z,main_loop
    call next_frame
    jp main_loop

reset_run:
    ld a,1
    ld (mode),a
    xor a
    ld (scene),a
    ld (frame),a
    ld (scene_pass),a
    ld (spark),a
    ld (graze_gate),a
    ld (loop_count),a
    ld hl,score
    ld b,6
reset_digits:
    ld (hl),a
    inc hl
    djnz reset_digits
    ld a,128
    ld (player_x),a
    ld a,166
    ld (player_y),a
    call sound_init
    ret

next_frame:
    ld a,(frame)
    inc a
    and 127
    ld (frame),a
    ret nz
    ld a,(scene_pass)
    xor 1
    ld (scene_pass),a
    ret nz
    ld a,(scene)
    inc a
    cp WAVE_COUNT
    jr c,scene_ready
    ; Keep the six original waves first, then cycle the expanded wave set.
    ld hl,loop_count
    inc (hl)
    ld a,WAVE_LOOP_START
scene_ready:
    ld (scene),a
    ret

video_init:
    ld a,082h
    ld b,1
    call vdp_reg
    ld a,2
    ld b,0
    call vdp_reg
    ld a,6
    ld b,2
    call vdp_reg
    ld a,255
    ld b,3
    call vdp_reg
    ld a,3
    ld b,4
    call vdp_reg
    ld a,036h
    ld b,5
    call vdp_reg
    ld a,7
    ld b,6
    call vdp_reg
    ld a,1
    ld b,7
    call vdp_reg
    ld hl,base_patterns
    ld de,0
    ld bc,2048
    call vram_write
    ld hl,base_patterns
    ld de,00800h
    ld bc,2048
    call vram_write
    ld hl,base_patterns
    ld de,01000h
    ld bc,2048
    call vram_write
    ld hl,base_colors
    ld de,02000h
    ld bc,2048
    call vram_write
    ld hl,base_colors
    ld de,02800h
    ld bc,2048
    call vram_write
    ld hl,base_colors
    ld de,03000h
    ld bc,2048
    call vram_write
    ld hl,base_masks
    ld de,mask_ram
    ld bc,306
    ldir
    ld hl,names
    ld de,01800h
    ld bc,768
    call vram_write
    ld hl,names
    ld de,01C00h
    ld bc,768
    call vram_write
    ld hl,sprite_patterns
    ld de,03800h
    ld bc,96
    call vram_write
    ld a,208
    ld (sat_ram),a
    ld hl,sat_ram
    ld de,01B00h
    ld bc,12
    call vram_write
    ld hl,sat_ram
    ld de,01B80h
    ld bc,12
    call vram_write
    in a,(099h)
    ld a,0C2h
    ld b,1
    call vdp_reg
    ret

vdp_reg:
    out (099h),a
    ld a,b
    or 080h
    out (099h),a
    ret

wait_vblank:
    in a,(099h)
    and 080h
    jr z,wait_vblank
    ret

; HL source, DE VRAM destination, BC length. 30T spacing including OUTI.
vram_write:
    ld a,e
    out (099h),a
    ld a,d
    or 040h
    out (099h),a
    ld a,c
    ld c,098h
    or a
    jr z,vram_blocks
    push bc
    ld b,a
vram_tail:
    outi
    nop
    jp nz,vram_tail
    pop bc
vram_blocks:
    ld a,b
    or a
    ret z
vram_block:
    ld b,0
vram_bytes:
    outi
    nop
    jp nz,vram_bytes
    dec a
    jr nz,vram_block
    ret

decode_frame:
    call clear_names
    ld a,(scene)
    ld l,a
    ld h,0
    ; 16-bit index: (scene * 128 + frame) * 3, safe for all generated waves.
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    add hl,hl
    ld a,(frame)
    ld e,a
    ld d,0
    add hl,de
    ld d,h
    ld e,l
    add hl,hl
    add hl,de
    ld de,frame_index
    add hl,de
    ld a,(hl)
    ld (06800h),a
    inc hl
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    ld a,(page)
    or a
    ld a,0
    jr z,decode_page
    ld a,32
decode_page:
    ld (dyn_offset),a
    add a,153
    ld (dyn_id),a
    ld a,(hl)
    inc hl
    ld (dyn_count),a
    or a
    jr z,decode_names
decode_dynamic:
    ld e,(hl)
    inc hl
    ld d,(hl)
    inc hl
    push hl
    ld a,(dyn_id)
    ld l,a
    ld h,0
    add hl,hl
    ld bc,mask_ram
    add hl,bc
    ld (hl),e
    inc hl
    ld (hl),d
    pop hl
    push hl
    ld a,(dyn_id)
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    ex de,hl
    pop hl
    push hl
    push de
    ld bc,8
    call vram_write
    pop de
    pop hl
    ld a,d
    add a,8
    ld d,a
    push hl
    push de
    ld bc,8
    call vram_write
    pop de
    pop hl
    ld a,d
    add a,8
    ld d,a
    ld bc,8
    call vram_write
    ld a,(dyn_id)
    inc a
    ld (dyn_id),a
    ld a,(dyn_count)
    dec a
    ld (dyn_count),a
    jr nz,decode_dynamic
decode_names:
    ld de,names
    ld a,(dyn_offset)
    ld c,a
decode_token:
    ld a,(hl)
    inc hl
    or a
    ret z
    bit 7,a
    jr nz,decode_zeros
    ld b,a
decode_literals:
    ld a,(hl)
    inc hl
    cp 153
    jr c,decode_store
    cp 185
    jr nc,decode_store
    add a,c
decode_store:
    ld (de),a
    inc de
    djnz decode_literals
    jr decode_token
decode_zeros:
    and 127
    inc a
    add a,e
    ld e,a
    jr nc,decode_token
    inc d
    jr decode_token

; This routine runs with DI. PUSH fills 768 bytes faster than a byte loop.
; Return address and caller stack stay intact while SP visits the back RAM table.
clear_names:
    ld (saved_sp),sp
    ld sp,names+768
    ld hl,0
    ld b,32
clear_name_block:
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    push hl
    djnz clear_name_block
    ld sp,(saved_sp)
    ret

; Positive input bits: left/right/up/down/fire/slow/ESC/demo.
input_read:
    in a,(0AAh)
    push af
    and 0F0h
    or 8
    out (0AAh),a
    in a,(0A9h)
    cpl
    ld d,a
    ld e,0
    bit 4,d
    jr z,input_right
    set 0,e
input_right:
    bit 7,d
    jr z,input_up
    set 1,e
input_up:
    bit 5,d
    jr z,input_down
    set 2,e
input_down:
    bit 6,d
    jr z,input_fire
    set 3,e
input_fire:
    bit 0,d
    jr z,input_row6
    set 4,e
input_row6:
    in a,(0AAh)
    and 0F0h
    or 6
    out (0AAh),a
    in a,(0A9h)
    bit 0,a
    jr nz,input_esc
    set 5,e
input_esc:
    in a,(0AAh)
    and 0F0h
    or 7
    out (0AAh),a
    in a,(0A9h)
    bit 2,a
    jr nz,input_demo
    set 6,e
input_demo:
    in a,(0AAh)
    and 0F0h
    or 3
    out (0AAh),a
    in a,(0A9h)
    bit 1,a ; D is row3 bit1; row2 bit7 is B.
    jr nz,input_restore
    set 7,e
input_restore:
    pop af
    out (0AAh),a
    ld a,7
    out (0A0h),a
    in a,(0A2h)
    and 03Fh
    or 080h
    out (0A1h),a
    ld a,15
    out (0A0h),a
    in a,(0A2h)
    ld d,a
    and 0AFh
    or 3
    out (0A1h),a
    ld a,14
    out (0A0h),a
    in a,(0A2h)
    cpl
    ld b,a
    bit 2,b
    jr z,joy_right
    set 0,e
joy_right:
    bit 3,b
    jr z,joy_up
    set 1,e
joy_up:
    bit 0,b
    jr z,joy_down
    set 2,e
joy_down:
    bit 1,b
    jr z,joy_fire
    set 3,e
joy_fire:
    bit 4,b
    jr z,joy_slow
    set 4,e
joy_slow:
    bit 5,b
    jr z,joy_restore
    set 5,e
joy_restore:
    ld a,15
    out (0A0h),a
    ld a,d
    out (0A1h),a
    ld a,e
    ret

move_player:
    ld a,(keys)
    ld b,a
    ld c,3
    bit 5,b
    jr z,speed_ready
    ld c,1
speed_ready:
    ld a,(player_x)
    bit 0,b
    jr z,move_right
    sub c
move_right:
    bit 1,b
    jr z,clamp_x
    add a,c
clamp_x:
    cp 8
    jr nc,clamp_x_max
    ld a,8
clamp_x_max:
    cp 248
    jr c,store_x
    ld a,247
store_x:
    ld (player_x),a
    ld a,(player_y)
    bit 2,b
    jr z,move_down
    sub c
move_down:
    bit 3,b
    jr z,clamp_y
    add a,c
clamp_y:
    cp 32
    jr nc,clamp_y_max
    ld a,32
clamp_y_max:
    cp 181
    jr c,store_y
    ld a,180
store_y:
    ld (player_y),a
    ret

; Occupancy at actual visible pixel D=x,E=y. No VRAM reads and no invisible bullets.
point_occupied:
    ld a,d
    and 6
    rrca
    ld c,a
    ld a,e
    and 6
    add a,a
    or c
    add a,a
    ld l,a
    ld h,0
    ld bc,bit_words
    add hl,bc
    ld c,(hl)
    inc hl
    ld b,(hl)
    push bc
    ld a,e
    and 0F8h
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    ld a,d
    rrca
    rrca
    rrca
    and 31
    ld c,a
    ld b,0
    add hl,bc
    ld bc,names
    add hl,bc
    ld l,(hl)
    ld h,0
    add hl,hl
    ld bc,mask_ram
    add hl,bc
    ld a,(hl)
    inc hl
    ld h,(hl)
    ld l,a
    pop bc
    ld a,l
    and c
    ld c,a
    ld a,h
    and b
    or c
    ret

collisions:
    ; A small 3x3 core; the 9x9 visual cross is not all a hitbox.
    ld a,(player_y)
    dec a
    ld (query_y),a
    ld b,3
hit_row:
    push bc
    ld a,(player_x)
    dec a
    ld d,a
    ld a,(query_y)
    ld e,a
    ld b,3
hit_column:
    push bc
    push de
    call point_occupied
    pop de
    pop bc
    or a
    jr nz,hit_found
    inc d
    djnz hit_column
    ld hl,query_y
    inc (hl)
    pop bc
    djnz hit_row
    ; The 2-pixel grid samples every 2x2 bullet within a 14x14 graze region.
    xor a
    ld (last_graze),a
    ld a,(player_y)
    sub 6
    ld (query_y),a
    ld b,7
graze_row:
    push bc
    ld a,(player_x)
    sub 6
    ld d,a
    ld a,(query_y)
    ld e,a
    ld b,7
graze_column:
    push bc
    push de
    call point_occupied
    pop de
    pop bc
    or a
    jr nz,graze_found
    inc d
    inc d
    djnz graze_column
    ld hl,query_y
    inc (hl)
    inc (hl)
    pop bc
    djnz graze_row
    xor a
    ld (graze_gate),a
    ret
hit_found:
    pop bc
    ld a,2
    ld (mode),a
    call update_high
    call sound_hit
    ret
graze_found:
    pop bc
    ld a,1
    ld (last_graze),a
    ld a,7
    ld (spark),a
    ld a,(graze_gate)
    inc a
    and 3
    ld (graze_gate),a
    cp 1
    ret nz
    ld a,5
    call add_score
    call sound_graze
    ret

add_score:
    ld hl,score
    ld b,6
score_carry:
    add a,(hl)
    cp 10
    jr c,score_store
    sub 10
    ld (hl),a
    inc hl
    ld a,1
    djnz score_carry
    ret
score_store:
    ld (hl),a
    ret

update_high:
    ld hl,score+5
    ld de,high_score+5
    ld b,6
high_compare:
    ld a,(de)
    cp (hl)
    jr c,high_copy
    ret nz
    dec hl
    dec de
    djnz high_compare
    ret
high_copy:
    ld hl,score
    ld de,high_score
    ld bc,6
    ldir
    ret

; String byte zero terminates. Coordinates are encoded directly as RAM pointers.
put_text:
    ld a,(hl)
    inc hl
    or a
    ret z
    cp ' '
    jr nz,text_not_space
    ld a,217
    jr text_store
text_not_space:
    cp '-'
    jr nz,text_not_dash
    ld a,255
    jr text_store
text_not_dash:
    cp ':'
    jr nz,text_not_colon
    ld a,254
    jr text_store
text_not_colon:
    cp 'A'
    jr nc,text_letter
    sub '0'
    add a,218
    jr text_store
text_letter:
    sub 'A'
    add a,228
text_store:
    ld (de),a
    inc de
    jr put_text

put_digits:
    ld b,6
digits_loop:
    ld a,(hl)
    add a,218
    ld (de),a
    dec hl
    inc de
    djnz digits_loop
    ret

overlay:
    ld hl,text_score
    ld de,names+33
    call put_text
    ld hl,score+5
    ld de,names+39
    call put_digits
    ld hl,text_wave
    ld de,names+54
    call put_text
    ld a,(scene)
    inc a
    ld b,218
wave_tens:
    cp 10
    jr c,wave_digits
    sub 10
    inc b
    jr wave_tens
wave_digits:
    add a,218
    ld (names+60),a
    ld a,b
    ld (names+59),a
    ld a,(mode)
    cp 1
    jp z,overlay_entry_hint
    cp 4
    jr nz,overlay_menu
    call overlay_entry_hint
    ld hl,text_demo
    ld de,names+9
    jp put_text
overlay_menu:
    ; Solid character-space panel; masked bullets cannot collide in a menu.
    ld hl,names+5*32+3
    ld b,14
panel_row:
    push bc
    ld b,26
panel_column:
    ld (hl),217
    inc hl
    djnz panel_column
    ld de,6
    add hl,de
    pop bc
    djnz panel_row
    ld hl,text_title
    ld de,names+6*32+8
    call put_text
    ld hl,text_over
    ld de,names+8*32+12
    call put_text
    ld hl,text_pcg
    ld de,names+10*32+5
    call put_text
    ld a,(mode)
    cp 2
    jr nz,overlay_not_hit
    ld hl,text_hit
    ld de,names+12*32+11
    call put_text
    jr overlay_start
overlay_not_hit:
    cp 3
    jr nz,overlay_controls
    ld hl,text_pause
    ld de,names+12*32+9
    call put_text
    ret
overlay_controls:
    ld hl,text_move
    ld de,names+12*32+5
    call put_text
overlay_start:
    ld hl,text_start
    ld de,names+14*32+7
    call put_text
    ld hl,text_focus
    ld de,names+16*32+7
    call put_text
    ld hl,text_demo_key
    ld de,names+18*32+11
    call put_text
    ret

overlay_entry_hint:
    ; New-wave entry warnings occupy the unused HUD row above the bullet area.
    ld a,(frame)
    cp 32
    ret nc
    ld a,(scene)
    ld l,a
    ld h,0
    ld de,wave_entry_hints
    add hl,de
    ld a,(hl)
    or a
    ret z
    ld hl,text_from_below
    dec a
    jr z,entry_hint_text
    ld hl,text_from_sides
entry_hint_text:
    ld de,names+64+10
    jp put_text

prepare_sprite:
    ld a,(mode)
    or a
    jr nz,sprite_visible
    ld a,208
    ld (sat_ram),a
    ret
sprite_visible:
    ld a,(player_y)
    sub 8
    ld (sat_ram),a
    ld (sat_ram+4),a
    ld a,(player_x)
    sub 7
    ld (sat_ram+1),a
    ld (sat_ram+5),a
    xor a
    ld (sat_ram+2),a
    ld a,7
    ld (sat_ram+3),a
    ld a,(mode)
    cp 2
    jr nz,sprite_not_hit
    ld a,9
    ld (sat_ram+3),a
sprite_not_hit:
    ld a,4
    ld (sat_ram+6),a
    ld a,(spark)
    or a
    ld a,0
    jr z,sprite_no_graze
    ld a,5
sprite_no_graze:
    ld (sat_ram+7),a
    ld a,208
    ld (sat_ram+8),a
    ld (sat_ram+16),a
    ; Visible, non-colliding emitter diamonds warn about interior birth points.
    ; Two emitters + player + graze occupy at most four sprites on any line.
    ; Five bytes per wave: count (0..2), x1,y1,x2,y2, in screen pixels.
    ld a,(scene)
    ld l,a
    ld h,0
    ld d,h
    ld e,l
    add hl,hl
    add hl,hl
    add hl,de
    ld de,wave_emitters
    add hl,de
    ld b,(hl)
    inc hl
    ld a,b
    or a
    ret z
    ld a,13
    ld (sat_ram+11),a
    ld a,5
    ld (sat_ram+15),a
    ld de,sat_ram+8
emitter_sprite:
    ld a,(hl)
    sub 7
    inc de
    ld (de),a
    inc hl
    dec de
    ld a,(hl)
    sub 8
    ld (de),a
    inc hl
    inc de
    inc de
    ld a,8
    ld (de),a
    inc de
    inc de
    djnz emitter_sprite
    ld a,208
    ld (de),a
    ret

text_score: db 'SCORE',0
text_wave: db 'WAVE',0
text_demo: db 'DEMO SPACE:EXIT',0
text_title: db 'SATOREINKER',0
text_over: db '- OVER -',0
text_pcg: db 'MSX1 EXPANDED WAVES',0
text_hit: db 'RUN OVER',0
text_pause: db 'ESC TO RESUME',0
text_move: db 'ARROWS OR JOYSTICK',0
text_start: db 'SPACE TO START',0
text_focus: db 'SHIFT TO FOCUS',0
text_demo_key: db 'D DEMO',0
text_from_below: db 'FROM BELOW',0
text_from_sides: db 'FROM SIDES',0

spread_nibble: db 0,192,48,240,12,204,60,252,3,195,51,243,15,207,63,255
bit_words: dw 1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768

; 16x16 pattern storage: left 16 rows then right 16 rows. Cross centered at(7,7).
sprite_patterns:
    db 0,0,0,0,1,1,3,15,3,1,1,0,0,0,0,0
    db 0,0,0,0,0,0,128,224,128,0,0,0,0,0,0,0
    ; Sparse graze sparks around the 14x14 detection vicinity, not a shield ring.
    db 0,2,0,0,0,32,0,0,0,0,32,0,0,2,0,0
    db 0,0,16,0,0,0,0,0,0,0,0,0,16,0,0,0
    db 0,0,0,1,2,4,8,16,8,4,2,1,0,0,0,0
    db 0,0,0,0,128,64,32,16,32,64,128,0,0,0,0,0

    include 'src/sound.asm'
    include 'assets/waves.inc'
base_patterns: incbin 'work/build/patterns.bin'
base_colors: incbin 'work/build/colors.bin'
base_masks: incbin 'assets/base-masks.bin'
frame_index: incbin 'assets/index.bin'
runtime_end:
