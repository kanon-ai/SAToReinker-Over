"""Native NTSC controls, measured update rate, and genuine emulator captures."""
from pathlib import Path
import hashlib, json, shutil, sys
from emulator_support import OpenMSX

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
SYM=json.loads((ROOT/'work/build/symbols.json').read_text())
ROM=OUT/'SAToReinker-Over-MSX1-PCG-v0.1.1.rom'

def main():
    report={'physical_hardware_tested':False,'rom_sha256':hashlib.sha256(ROM.read_bytes()).hexdigest(),'checks':[]}
    def check(name, condition, **data):
        report['checks'].append(dict(name=name,passed=bool(condition),**data))
        print(name,condition,data,flush=True)
        assert condition,name
    with OpenMSX('ntsc', capture=True) as e:
        private=e.profile.directory/'tested.rom'
        shutil.copyfile(ROM,private)
        e.enable_capture()
        e.load_rom(private)
        e.run_for(5)
        report['machine']=e.machine_info()
        get=lambda n,size=1:e.read_symbol(SYM,n,size)
        def tap(row,mask):
            e.key(row,mask);e.run_for(.15);e.key(row,mask,False);e.run_for(.15)
        check('physical-32KiB-RAM',report['machine']['ram_bytes']==32768)
        check('physical-16KiB-VRAM',report['machine']['vram_bytes']==16384)
        check('title-on-boot',get('mode')==0,mode=get('mode'))
        e.run_for(.2)
        e.screenshot(OUT/'title.png',640)
        tap(8,1)
        check('space-start',get('mode')==1)
        x=get('player_x')
        e.key(8,16);e.run_for(.2);e.key(8,16,False)
        normal=x-get('player_x')
        check('left-arrow',normal>0,pixels=normal)
        x=get('player_x')
        e.key(6,1);e.key(8,16);e.run_for(.2);e.key(8,16,False);e.key(6,1,False)
        slow=x-get('player_x')
        check('shift-focus',0<slow<normal,normal_pixels=normal,focus_pixels=slow)
        tap(7,4)
        check('pause',get('mode')==3)
        f=get('frame');sc=get('scene');digits=e.read_block('memory',SYM['score'],6)
        e.run_for(.3)
        check('pause-freezes-game',f==get('frame') and sc==get('scene') and digits==e.read_block('memory',SYM['score'],6))
        tap(7,4)
        check('resume',get('mode')==1)
        # A normal run, no RAM edits: stand still until an actual bullet hits.
        for _ in range(50):
            if get('mode')==2:break
            e.run_for(.25)
        check('native-hit-gameover',get('mode')==2)
        e.run_for(.3)
        e.screenshot(OUT/'game-over.png',640)
        check('high-score-retained',any(e.read_block('memory',SYM['high_score'],6)))
        tap(8,1)
        check('restart-after-hit',get('mode')==1)
        # Fresh boot and D enter a documented invincible showcase through real input.
        e.load_rom(private);e.run_for(4);tap(3,2)
        check('keyboard-demo-mode',get('mode')==4)
        e.key(8,1);e.run_for(.35)
        check('demo-space-exits-to-title',get('mode')==0)
        e.run_for(.3)
        check('held-demo-exit-does-not-start',get('mode')==0)
        e.key(8,1,False);e.run_for(.1)
        tap(8,1)
        check('start-after-demo-exit',get('mode')==1)
        e.load_rom(private);e.run_for(4);tap(3,2);tap(7,4)
        check('paused-demo',get('mode')==3 and get('previous_mode')==4)
        tap(8,1)
        check('paused-demo-space-exits',get('mode')==0)
        tap(3,2)
        check('demo-reentry-after-exit',get('mode')==4)
        from PIL import Image
        capture_dir=ROOT/'work/capture'
        capture_dir.mkdir(parents=True,exist_ok=True)
        rates=[]
        for target in range(6):
            while get('scene')!=target:e.run_for(.1)
            while get('frame')<20:e.run_for(.02)
            t=float(e.command('machine_info time'));u=get('update_count',2)
            images=[]
            for j in range(100):
                e.run_for(1/30)
                path=capture_dir/f'scene-{target}-{j:03}.png'
                e.screenshot(path,640)
                with Image.open(path) as im:images.append(im.convert('RGB'))
            elapsed=float(e.command('machine_info time'))-t
            count=(get('update_count',2)-u)&65535
            rates.append(dict(scene=target+1,updates=count,emulated_seconds=elapsed,updates_per_second=count/elapsed))
            check(f'scene-{target+1}-continues',count>0)
            images[(59,50,57,60,56,51)[target]-20].save(OUT/f'wave-{target+1}.png')
            if target in (1,3):
                images[0].save(OUT/f'wave-{target+1}-emulator.gif',save_all=True,append_images=images[1:],duration=([30,30,40]*34)[:len(images)],loop=0,optimize=False)
        report['rates']=rates
        report['capture_mode']='Keyboard-selected D showcase; invincible and labelled DEMO on screen. No gameplay-memory writes.'
        check('strict-VRAM-timing',e.timing_violations()==0,violations=e.timing_violations())
        report['vram_timing_violations']=e.timing_violations()
    (OUT/'ntsc-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report['rates'],indent=2))

if __name__=='__main__':main()
