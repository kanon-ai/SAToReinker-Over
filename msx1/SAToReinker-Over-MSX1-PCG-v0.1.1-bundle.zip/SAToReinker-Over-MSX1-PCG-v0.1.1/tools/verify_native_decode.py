"""Exercise the built MSX1 ROM's decoder and collision routine in openMSX.

This deliberately labelled targeted test writes scene/frame/page/mode variables
and CPU registers in one private emulator. It is not a recording of ordinary
gameplay. Collision fixtures temporarily edit name-table RAM, then restore it.
Only an original ROM copy is made: user BIOS images and save media are not copied.

Run after build.py and after emulator_support is working on the host:
    python tools/verify_native_decode.py
The module does not start openMSX when imported, or with --syntax-only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import time
import uuid

from emulator_support import OpenMSX, read_symbols, tcl_word


ROOT = Path(__file__).resolve().parents[1]
PEAK_FRAMES = (59, 50, 57, 60, 56, 51)
FIRST_DYNAMIC, DYNAMIC_COUNT = 153, 32
STACK_AREA, STACK_SIZE = 0xF2C0, 0x40
CALL_STACK, SENTINEL = 0xF2E0, 0xF2F0


def require(condition: bool, explanation: str):
    if not condition:
        raise AssertionError(explanation)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def embedded(rom: bytes, symbols: dict[str, int], name: str, size: int) -> bytes:
    start = 8192 + symbols[name] - 0x8000
    require(start >= 8192 and start + size <= 32768, f"{name} outside reserved runtime ROM")
    return rom[start:start + size]


def reference_pattern(mask: int) -> bytes:
    """Independent explicit pixel expansion, not generator.mask_pattern()."""
    result = bytearray(8)
    for y in range(8):
        for x in range(8):
            if mask & (1 << ((y // 2) * 4 + x // 2)):
                result[y] |= 0x80 >> x
    return bytes(result)


def reference_frame(rom: bytes, index: bytes, scene: int, frame: int, page: int):
    bank, cpu_address = struct.unpack_from("<BH", index, (scene * 128 + frame) * 3)
    require(4 <= bank < 64 and 0x6000 <= cpu_address < 0x8000, "Invalid frame index")
    position = bank * 8192 + cpu_address - 0x6000
    bank_end = (bank + 1) * 8192
    count = rom[position]
    position += 1
    require(count <= DYNAMIC_COUNT, "Dynamic PCG count exceeds 32")
    dynamic = []
    for _ in range(count):
        mask = struct.unpack_from("<H", rom, position)[0]
        require(rom[position + 2:position + 10] == reference_pattern(mask), "Ready PCG differs from its mask")
        dynamic.append(mask)
        position += 10
    names = bytearray()
    while True:
        require(position < bank_end, "Packet crosses an 8 KiB bank")
        token = rom[position]
        position += 1
        if token == 0:
            break
        if token >= 128:
            names.extend(bytes(token - 127))
        else:
            for tile in rom[position:position + token]:
                names.append(tile + 32 * page if 153 <= tile <= 184 else tile)
            position += token
        require(len(names) <= 768, "RLE exceeds the name table")
    require(len(names) == 768, "RLE does not fill the name table")
    require(position <= bank_end, "Packet ends outside its bank")
    return bytes(names), dynamic, {"bank": bank, "address": cpu_address}


def breakpoint(emu: OpenMSX, address: int, marker: str, condition: str = "") -> str:
    return emu.command(f"debug set_bp {address} {tcl_word(condition)} "
                       f"{{set {marker} 1;debug break}}")


def run_until(emu: OpenMSX, marker: str, setup: str = "", seconds: float = 10):
    emu.command(f"set {marker} 0;{setup};set pause off;debug cont")
    deadline = time.monotonic() + seconds
    while emu.command(f"set {marker}") != "1":
        if time.monotonic() > deadline:
            emu.command("set pause on;debug break")
            raise TimeoutError(f"Native breakpoint did not fire: {marker}; PC=" + emu.command("reg PC"))
        time.sleep(0.001)
    emu.command("set pause on")


def assert_bytes(actual: bytes, expected: bytes, label: str):
    if actual != expected:
        first = next((i for i, (a, b) in enumerate(zip(actual, expected)) if a != b), min(len(actual), len(expected)))
        raise AssertionError(f"{label}: byte {first}: native={actual[first:first+8].hex()} expected={expected[first:first+8].hex()}")


def native_collision_probes(emu: OpenMSX, symbols: dict[str, int], page: int):
    """Call the actual ROM routine at all microdot positions in 3 VRAM bands.

    A labelled fixture lays existing native-decoded single/pair/dynamic PCG
    indices into otherwise blank names RAM. Their masks remain unmodified.
    The real Z80 point_occupied routine is invoked, and its A/Z result is read.
    """
    saved_cpu = emu.read_block("CPU regs", 0, 28)
    saved_names = emu.read_block("memory", symbols["names"], 768)
    saved_stack = emu.read_block("memory", STACK_AREA, STACK_SIZE)
    masks = emu.read_block("memory", symbols["mask_ram"], 512)
    dynamic_range = range(FIRST_DYNAMIC + page * 32, FIRST_DYNAMIC + page * 32 + 32)
    mask_values = list(struct.unpack("<256H", masks))
    dynamic_indices = [i for i in dynamic_range if 3 <= mask_values[i].bit_count() < 16]
    require(dynamic_indices, f"Page {page}: no decoded dynamic mask for collision test")
    classes = ("single", "pair", "dynamic")
    fixture = bytearray(768)
    probes = []
    coverage = []
    for band, tile_row in enumerate((4, 12, 20)):
        for kind in classes:
            column = {"single": 5, "pair": 14, "dynamic": 23}[kind]
            cell = tile_row * 32 + column
            for bit in range(16):
                if kind == "single":
                    tile = 1 + bit
                elif kind == "pair":
                    target = (1 << bit) | (1 << ((bit + 5) % 16))
                    tile = next(i for i in range(33, 153) if mask_values[i] == target)
                else:
                    tile = next((i for i in dynamic_indices if mask_values[i] & (1 << bit)), None)
                    require(tile is not None, f"Dynamic masks do not cover positive bit {bit}")
                mask = mask_values[tile]
                # Odd pixel of each 2x2 dot proves the full block is collidable.
                x = column * 8 + (bit % 4) * 2 + 1
                y = tile_row * 8 + (bit // 4) * 2 + 1
                probes.append((x, y, True, f"page{page}/band{band}/{kind}/bit{bit}", cell, tile))
                empty = next(i for i in range(16) if not mask & (1 << i))
                probes.append((column*8+(empty % 4)*2, tile_row*8+(empty // 4)*2, False,
                               f"page{page}/band{band}/{kind}/empty{empty}", cell, tile))
            coverage.append({"page": page, "screen_bank": band, "kind": kind,
                             "positive_microdot_positions": list(range(16)),
                             "occupied_and_empty": True, "native_calls": 32})
    for x, y in ((0, 0), (255, 0), (0, 191), (255, 191), (4, 24), (250, 182), (128, 23), (128, 184)):
        probes.append((x, y, False, f"page{page}/border/{x},{y}", None, None))
    sentinel_marker = "::pcg_collision_return"
    bp = breakpoint(emu, SENTINEL, sentinel_marker)
    checked = 0
    try:
        emu.write_block("memory", symbols["names"], fixture)
        stack_fixture = bytearray([0xA7] * STACK_SIZE)
        struct.pack_into("<H", stack_fixture, CALL_STACK - STACK_AREA, SENTINEL)
        stack_fixture[SENTINEL - STACK_AREA] = 0xC9  # Not executed: breakpoint stops first.
        emu.write_block("memory", STACK_AREA, stack_fixture)
        for x, y, expected, label, cell, tile in probes:
            if cell is not None and fixture[cell] != tile:
                fixture[cell] = tile
                emu.write_block("memory", symbols["names"] + cell, bytes([tile]))
            run_until(emu, sentinel_marker,
                      f"reg PC {symbols['point_occupied']};reg DE {(x << 8) | y};"
                      f"reg SP {CALL_STACK};reg IX 42330;reg IY 23205;reg BC 4951;reg HL 9320")
            a, flags, de, ix, iy, sp = map(int, emu.command("list [reg A] [reg F] [reg DE] [reg IX] [reg IY] [reg SP]").split())
            result = a != 0
            zero = bool(flags & 0x40)
            require(result == expected and zero == (not expected), f"{label}: native A/Z mismatch")
            require(de == ((x << 8) | y), label + ": DE preservation failed")
            require(ix == 42330 and iy == 23205,
                    label + ": IX/IY preservation failed")
            require(sp == CALL_STACK + 2, label + ": stack imbalance")
            checked += 1
        after_stack = emu.read_block("memory", STACK_AREA, STACK_SIZE)
        for offset in range(STACK_SIZE):
            # PUSH BC legitimately writes two bytes immediately below SP.
            if offset not in (CALL_STACK - STACK_AREA - 2, CALL_STACK - STACK_AREA - 1):
                require(after_stack[offset] == stack_fixture[offset], f"Collision stack guard altered at {offset}")
        assert_bytes(emu.read_block("memory", symbols["mask_ram"], 512), masks, "Collision mask RAM preservation")
        assert_bytes(emu.read_block("memory", symbols["names"], 768), fixture, "Collision names RAM preservation")
    finally:
        emu.command(f"debug remove_bp {tcl_word(bp)}")
        emu.write_block("memory", symbols["names"], saved_names)
        emu.write_block("memory", STACK_AREA, saved_stack)
        emu.write_block("CPU regs", 0, saved_cpu)
    return {"native_calls": checked, "coverage": coverage,
            "fixture_label": "Targeted RAM fixture using native-decoded masks; not ordinary gameplay",
            "register_and_stack_guards": "passed", "ram_restored": True}


def verify(rom_path: Path, symbols_path: Path, output: Path):
    symbols = read_symbols(symbols_path)
    for name in ("frame_decoded", "main_loop", "point_occupied", "base_patterns", "base_colors",
                 "base_masks", "frame_index", "mask_ram", "names", "page", "scene", "frame", "mode"):
        require(name in symbols, "Rebuild required: missing symbol " + name)
    rom = rom_path.read_bytes()
    require(len(rom) == 524288, "Expected a 512 KiB ROM")
    patterns = embedded(rom, symbols, "base_patterns", 2048)
    colors = embedded(rom, symbols, "base_colors", 2048)
    base_masks = embedded(rom, symbols, "base_masks", 306)
    index = embedded(rom, symbols, "frame_index", 768 * 3)
    runtime_size = symbols["runtime_end"] - 0x8000
    session = ROOT / "work" / ("native-decode-" + uuid.uuid4().hex[:10])
    session.mkdir(parents=True)
    private_rom = session / rom_path.name
    shutil.copyfile(rom_path, private_rom)
    results = []
    collisions = []
    with OpenMSX("ntsc", work=session) as emu:
        emu.load_rom(private_rom, "ASCII8")
        marker = "::pcg_frame_decoded"
        # C-BIOS uses page-2 RAM for its boot logo, so an address alone can
        # accidentally stop there before the cartridge has even initialized.
        entry_condition = ('[string equal [binary encode hex '
                           '[debug read_block memory 32768 16]] "' + rom[8192:8208].hex() + '"]')
        bp = breakpoint(emu, symbols["frame_decoded"], marker, entry_condition)
        try:
            run_until(emu, marker, seconds=20)
            info = emu.machine_info()
            require(info["ram_bytes"] == 32768 and info["vram_bytes"] == 16384, "Memory-limited machine mismatch")
            runtime_snapshot = emu.read_block("memory", 0x8000, runtime_size)
            assert_bytes(runtime_snapshot, rom[8192:8192 + runtime_size], "Copied native runtime")
            for page in (0, 1):
                # The additional MIRROR WINGS interval supplies native dynamic
                # masks with positive coverage of all sixteen microdot bits.
                for scene, peak in list(enumerate(PEAK_FRAMES)) + [(3, 15)]:
                    for frame in (peak - 1, peak, peak + 1):
                        scenario = f"targeted scene={scene}, frame={frame}, page={page}, mode=4"
                        other_first = FIRST_DYNAMIC + (1 - page) * 32
                        other_before = [emu.read_block("physical VRAM", band * 2048 + other_first * 8, 256)
                                        for band in range(3)]
                        for variable, value in (("scene", scene), ("frame", frame), ("page", page), ("mode", 4)):
                            emu.write_block("memory", symbols[variable], bytes([value]))
                        run_until(emu, marker, f"reg PC {symbols['main_loop']}")
                        expected_names, dynamic, address = reference_frame(rom, index, scene, frame, page)
                        assert_bytes(emu.read_block("memory", symbols["names"], 768), expected_names, scenario + " names")
                        mask_memory = emu.read_block("memory", symbols["mask_ram"], 512)
                        assert_bytes(mask_memory[:306], base_masks, scenario + " static masks")
                        first = FIRST_DYNAMIC + page * 32
                        for i, mask in enumerate(dynamic):
                            assert_bytes(mask_memory[(first+i)*2:(first+i+1)*2], struct.pack("<H", mask), scenario + " dynamic mask")
                        for band in range(3):
                            vram = emu.read_block("physical VRAM", band * 2048, 2048)
                            assert_bytes(vram[:153*8], patterns[:153*8], scenario + f" bank{band} fixed PCG")
                            assert_bytes(vram[217*8:], patterns[217*8:], scenario + f" bank{band} font PCG")
                            assert_bytes(vram[other_first*8:(other_first+32)*8], other_before[band], scenario + f" bank{band} front PCG preservation")
                            for i, mask in enumerate(dynamic):
                                assert_bytes(vram[(first+i)*8:(first+i+1)*8], reference_pattern(mask), scenario + f" bank{band} expanded PCG")
                            assert_bytes(emu.read_block("physical VRAM", 0x2000 + band*2048, 2048), colors, scenario + f" bank{band} colors")
                        results.append({"scenario": scenario, **address, "dynamic_count": len(dynamic),
                                        "name_bytes_checked": 768, "pattern_banks_checked": 3,
                                        "opposite_page_unchanged": True})
                collisions.append(native_collision_probes(emu, symbols, page))
            assert_bytes(emu.read_block("memory", 0x8000, runtime_size), runtime_snapshot, "Runtime code preservation")
            timing = emu.timing_violations()
            require(timing == 0, f"Too-fast VRAM accesses reported: {timing}")
        finally:
            emu.command(f"debug remove_bp {tcl_word(bp)}")
    require(private_rom.read_bytes() == rom and rom_path.read_bytes() == rom, "ROM file changed during test")
    report = {"passed": True, "test_kind": "Actual Z80 ROM execution in a private openMSX process",
              "targeted_state_injection": True, "ordinary_gameplay_capture": False,
              "physical_hardware_tested": False, "source_rom": str(rom_path.resolve()),
              "private_rom": str(private_rom), "rom_sha256": sha256(rom), "machine": info,
              "decoder_scenarios": results, "collision_tests": collisions,
              "native_collision_calls": sum(c["native_calls"] for c in collisions),
              "vram_timing_violations": timing, "rom_and_runtime_preserved": True}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, default=ROOT / "outputs/SAToReinker-Over-MSX1-PCG-v0.1.1.rom")
    parser.add_argument("--symbols", type=Path, default=ROOT / "work/build/symbols.json")
    parser.add_argument("--output", type=Path, default=ROOT / "work/verification/native-decode.json")
    parser.add_argument("--syntax-only", action="store_true", help="validate imports and asset oracle; do not launch openMSX")
    args = parser.parse_args()
    if args.syntax_only:
        symbols = read_symbols(args.symbols)
        rom = args.rom.read_bytes()
        index = embedded(rom, symbols, "frame_index", 768 * 3)
        for scene in range(6):
            for frame in range(128):
                for page in (0, 1):
                    names, masks, _ = reference_frame(rom, index, scene, frame, page)
                    require(len(names) == 768, "Oracle error")
                    require(all(len(reference_pattern(mask)) == 8 for mask in masks), "Pattern oracle error")
        print(json.dumps({"syntax_and_oracle_only": True, "native_execution_performed": False,
                          "packet_page_combinations_checked": 1536}))
        return
    report = verify(args.rom, args.symbols, args.output)
    print(json.dumps({"passed": report["passed"], "report": str(args.output.resolve()),
                      "native_decoder_scenarios": len(report["decoder_scenarios"]),
                      "native_collision_calls": report["native_collision_calls"]}))


if __name__ == "__main__":
    main()
