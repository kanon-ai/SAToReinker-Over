@echo off
setlocal
cd /d "%~dp0"
if not defined OPENMSX_EXE set "OPENMSX_EXE=C:\Program Files\openMSX\openmsx.exe"
if not exist "%OPENMSX_EXE%" (
 echo openMSX not found. Set OPENMSX_EXE to your openmsx.exe.
 pause
 exit /b 1
)
if not exist "SAVE.dsk" copy /b "blank-save.dsk" "SAVE.dsk" >nul
"%OPENMSX_EXE%" -machine Panasonic_FS-A1ST -exta gfx9000 -cartb "%~dp0SAToReinker-Over.rom" -romtype ASCII8 -diska "%~dp0SAVE.dsk" -script "%~dp0launch.tcl"
endlocal
