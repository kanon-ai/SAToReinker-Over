SAToReinker-Over / Windows試遊セット

開発中の試作版です。実機動作は未確認、無保証です。
Experimental prototype; real hardware has not been verified. Provided as-is.

START.cmdで起動します。別途openMSXと、ご自身で用意したTurbo RのBIOSが必要です。
既定のopenMSXパス: C:\Program Files\openMSX\openmsx.exe
別の場所の場合は環境変数OPENMSX_EXEを指定してください。
Launch START.cmd with your own openMSX installation and system ROMs.
Target: MSX turbo R + V9990, R800 mode, 512 KiB ASCII8 ROM.

矢印キー／1番ポートのパッド: 移動 / Move
Space／ボタン1: 開始、プレイ中は低速移動 / Start, focus movement
X／ボタン2: タイトル・結果画面からリプレイ / Replay view from menus
Space／ボタン1: リプレイ中断 / Cancel replay
S: 保存 / Save   L: 読込 / Load (keyboard required)

保存先はA:SATORI2.RPLの1件です。Sで同名ファイルを上書きします。
DISK OKを確認してから終了してください。エラー時は保存を中止してメニューへ戻し、
RAM上のリプレイを保持する設計です。途中のディスクファイルは不完全な場合があります。
Save overwrites A:SATORI2.RPL. Wait for DISK OK. Interrupted writes are not rolled back.

更新ZIPは別フォルダに展開し、既存のSAVE.dskを上書きしないでください。
同梱SAVE.dskは空のディスクです。エミュレータを複数起動して同じディスクを共有しないでください。
Extract updates into a separate folder and preserve your existing SAVE.dsk.

上限は16384入力です。保存形式・ルールID2を維持しています。
既存のSATORI2.RPLは再生可能です。8192入力を超える記録には16384入力対応版が必要です。
旧SATORI.RPL（ルールID1）は非対応です。今回の映像初期化で互換性は変えていません。
Format/rule ID 2 is unchanged. Longer replays require the 16384-input ROM.

2026-09-09: Video9000映像出力の起動時初期化を追加。
openMSXのFS-A1ST + GFX9000／Video9000で確認。実機・Nextor等の別ディスク環境は未検証です。
Verified in openMSX; physical hardware and other disk interfaces remain unverified.

不具合報告は歓迎しますが、修正・継続開発・個別対応を保証するものではありません。
No warranty of operation, performance, compatibility or data preservation; support is not promised.
詳細 / Details: https://github.com/kanon-ai/SAToReinker-Over
